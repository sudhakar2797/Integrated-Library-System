<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><?php
        $titleerror = $error = $publicationerror = $statuserror = $authorerror = $subjecterror = $dateofadderror = $detailerror = "";
        $acc = 0;
        if (isset($_POST['update'])) {
            $acc = 1;
            $error = " Nothing Updated";
            require 'dbconnect.php';
            if (!empty($_POST['bookid'])) {
                $bookid = $_POST['bookid'];
                $query = "SELECT * FROM book WHERE id='$bookid'";
                $sql = $conn->query($query);
                if ($sql->num_rows > 0) {
                    if (!empty($_POST['mlan'])) {
                        $title = $_POST['mlan'];
                        $sql = "UPDATE book SET accessno='$title' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $titleerror = " Access No Successfully Updated";
                        } else {
                            $titleerror = "Access No Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['nbookid'])) {
                        $title = $_POST['nbookid'];
                        $sql = "UPDATE book SET id='$title' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $titleerror .= "   Book ID Successfully Updated";
                        } else {
                            $titleerror .= "   Book ID Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newtitle'])) {
                        $title = $_POST['newtitle'];
                        $sql = "UPDATE book SET title='$title' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $titleerror = " Title Successfully Updated";
                        } else {
                            $titleerror = " Title Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newpublication'])) {
                        $publication = $_POST['newpublication'];
                        $sql = "UPDATE book SET publication='$publication' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $publicationerror = "Publication Successfully Updated";
                        } else {
                            $titleerror = " Publication Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newauthor'])) {
                        $author = $_POST['newauthor'];
                        $sql = "UPDATE book SET author='$author' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $authorerror = "Author Successfully Updated";
                        } else {
                            $authorerror = " Author Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newsubject'])) {
                        $subject = $_POST['newsubject'];
                        $sql = "UPDATE book SET subject='$subject' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $subjecterror = "Subject Successfully Updated";
                        } else {
                            $subjecterror = " Subject Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newdetail'])) {
                        $detail = $_POST['newdetail'];
                        $sql = "UPDATE book SET detail='$detail' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $detailerror = "Detail Successfully Updated";
                        } else {
                            $detailerror = "Detail Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newdateofadd'])) {
                        $dateofadd = $_POST['newdateofadd'];
                        $old = strtotime($dateofadd);
                        $dateofadd = date('Y-m-d ', $old);
                        $sql = "UPDATE book SET dateofadd='$dateofadd' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $dateofadderror = "Date Of Add Successfully Updated";
                        } else {
                            $dateofadderror = " Date Of Add Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newstatus'])) {
                        $status = $_POST['newstatus'];
                        $sql = "UPDATE book SET status='$status' WHERE id='$bookid'";
                        if ($conn->query($sql)) {
                            $statuserror = "Status Successfully Updated";
                        } else {
                            $statuserror = " Status Not Updated Please Try Again";
                        }
                    }
                } else {
                    $error = "Please Enter Valid BookId";
                }
            } else {
                $error = "Please Enter BookId";
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Book &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000;">
                                            <style>             
                                                input[type=text]:focus {
                                                    width: 55%;
                                                }
                                                input[type=text]:hover {
                                                    width: 55%;
                                                }
                                            </style>
                                            <center> 
                                                <form method="post" action="BookUpdate.php">
                                                    <link rel="stylesheet" href="assets/css/update.css">
                                                    <?php if ($acc == 1) { ?>  <link href="assets/css/alert.css" rel="stylesheet">
                                                        <div class="alert alert-danger">
                                                            <span class="closebtn">&times;</span>  
                                                            <?php
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $error . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $titleerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $authorerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $subjecterror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $publicationerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $detailerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $dateofadderror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:#fff;font-family:calibri;">' . $statuserror . '</h3>';
                                                            ?> </div>
                                                        <script>
                                                            var close = document.getElementsByClassName("closebtn");
                                                            var i;

                                                            for (i = 0; i < close.length; i++) {
                                                                close[i].onclick = function () {
                                                                    var div = this.parentElement;
                                                                    div.style.opacity = "0";
                                                                    setTimeout(function () {
                                                                        div.style.display = "none";
                                                                    }, 600);
                                                                }
                                                            }
                                                        </script><?php } ?> 
                                                    <div  align="center">
                                                        <ul class="tab">
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Id')" id="defaultOpen">Id</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Title')">Title</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Author')">Author</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Subject')">Subject</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Publication')">Publication</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Detail')">Detail</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'DateOfAdd')">DateOfAdd</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Status')">Status</a></li>
                                                        </ul>
                                                        <div id="Id" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <center> <image src="assets/img/image/bookupdate.jpg" width="100px" height="100px"/></center>
                                                            <h3 style="font-size:25px;color:maroon;font-family:calibri;">Book Update</h3>
                                                            <br><spen style="color:#6600ff;font-size: #12px"> * Book ID</spen>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <input type="text" name="bookid" placeholder="* Enter The BookId, You Want To Update" required/><br>
                                                            <br><spen style="color:#6600ff;font-size: #12px">New Book ID</spen>&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <input type="text" name="nbookid" placeholder="Enter The New BookId"/><br>
                                                            <br><spen style="color:#6600ff;font-size: #12px">Access Number</spen>
                                                            <input type="text" name="mlan" placeholder="Enter The Access No"/><br>
                                                            <br><button name="update" class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;update</button>
                                                            <h4 style="font-family: calibri;font-size: 20px;color:indigo; ">*If You Don't Known About The BookId Please Use " Display Option " To Find The BookId*</h4>
                                                        </div>
                                                        <div id="Title" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Book Title</h3><br>
                                                            <input type="text" name="newtitle" placeholder="        Enter The  New Book Title   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Author" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Author Name </h3><br>
                                                            <input type="text" name="newauthor" placeholder="        Enter The New AuthorName    "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Subject" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Subject Of The Book</h3><br>
                                                            <input type="text" name="newsubject" placeholder="        Enter The New Subject Name   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>

                                                        <div id="Publication" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change publication Of The Book</h3><br>
                                                            <input type="text" name="newpublication" placeholder="   Enter The New publication Name   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Detail" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Detail Of The Book</h3><br>
                                                            <input type="text" name="newdetail" placeholder="      Enter The New Detail Of Book   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="DateOfAdd" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Date Of Add</h3><br>
                                                            <input type="text" name="newdateofadd"  id="datepicker1" placeholder="        Enter The New Date Of Add   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Status" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Book Status</h3><br>
                                                            <input type="text" name="newstatus" placeholder="Enter Status available / notavailable   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                    </div>
                                                </form>
                                            </center>
                                            <script>
                                                function openCity(evt, cityName) {
                                                    var i, tabcontent, tablinks;
                                                    tabcontent = document.getElementsByClassName("tabcontent");
                                                    for (i = 0; i < tabcontent.length; i++) {
                                                        tabcontent[i].style.display = "none";
                                                    }
                                                    tablinks = document.getElementsByClassName("tablinks");
                                                    for (i = 0; i < tablinks.length; i++) {
                                                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                                                    }
                                                    document.getElementById(cityName).style.display = "block";
                                                    evt.currentTarget.className += " active";
                                                }
                                                // Get the element with id="defaultOpen" and click on it
                                                document.getElementById("defaultOpen").click();
                                            </script>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <link rel="stylesheet" href="jq/jquery-ui.css">
                <script src="jq/jquery.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
                <script src="jq/jquery-ui.js"></script>
                <script>
                                                $(function () {
                                                    $("#datepicker").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                                                $(function () {
                                                    $("#datepicker1").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker1").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                </script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
