<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><?php require 'dbconnect.php'; ?>
        <?php
        $error = "";
        if (isset($_POST['submit'])) {
            $file = $_FILES['file']['tmp_name'];
            $handle = fopen($file, "r");
            $c = 0;
            while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {
                $stmt = $conn->prepare("INSERT INTO project  VALUES (?,?,?,?,?,?,?,?)");
                $stmt->bind_param("ssssssss", $id, $title, $area, $by, $guide, $batch, $dateofadd, $status);
                $id = $filesop[0];
                $title = $filesop[1];
                $area = $filesop[2];
                $by = $filesop[3];
                $guide = $filesop[4];
                $batch = $filesop[5];
                $dateofadd = date('Y-m-d');
                $status = "available";
                if ($stmt->execute()) {
                    $c = $c + 1;
                } else {
                    $error = "check your data";
                }
            }
            $error = "You database has imported successfully. You have inserted [ $c ] records";
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Project Record &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">
                                    <?php if (!empty($error)) { ?>
                                        <link href="assets/css/alert.css" rel="stylesheet" />
                                        <h5 class="alert alert-success">
                                            <?php echo $error; ?>
                                            <span class="closebtn">&times;</span>  
                                            <script>
                                                var close = document.getElementsByClassName("closebtn");
                                                var i;

                                                for (i = 0; i < close.length; i++) {
                                                    close[i].onclick = function () {
                                                        var div = this.parentElement;
                                                        div.style.opacity = "0";
                                                        setTimeout(function () {
                                                            div.style.display = "none";
                                                        }, 600);
                                                    }
                                                }
                                            </script></h5><?php } ?>           

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="showback" style="color:#000;">
                                            <style>
                                                #yourBtn{
                                                    font-family: calibri;
                                                    width: 180px;
                                                    -webkit-border-radius: 5px;
                                                    -moz-border-radius: 5px;
                                                    text-align: center;
                                                    background-color: #357ae8;
                                                    color: white;
                                                    padding: 14px 20px;
                                                    margin: 8px 0;
                                                    border: none;
                                                    cursor: pointer;
                                                }
                                                #yourBtn:hover{
                                                    background-color: #0000FF;
                                                }
                                            </style>
                                            <link href="assets/css/bulk.css" rel="stylesheet">
                                            <center>
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <h2 style="color:black;font-family:calibri;">Project Record Insert</h2>
                                                            <form name="import" method="post" enctype="multipart/form-data">
                                                                <center> 
                                                                    <image src="assets/img/image/bulk.png" width="75px" height="75px"/>
                                                                    <image src="assets/img/image/excel.png" width="75px" height="75px"/>
                                                                    <image src="assets/img/image/data.png" width="75px" height="75px"/>
                                                                    <div id="yourBtn" onclick="getFile()">Click To Insert A Data</div>
                                                                    <div style='height: 0px;width: 0px; overflow:hidden;'><input id="upfile" type="file" name="file" value="upload" onchange="sub(this)" required/></div>
                                                                    <input class="btn btn-primary fa-1x" type="submit" name="submit" value="Insert" /></center>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </center>
                                            <script type="text/javascript">
                                                function getFile() {
                                                    document.getElementById("upfile").click();
                                                }
                                                function sub(obj) {
                                                    var file = obj.value;
                                                    var fileName = file.split("\\");
                                                    document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
                                                    document.myForm.submit();
                                                    event.preventDefault();
                                                }
                                            </script>
                                        </div>
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>

