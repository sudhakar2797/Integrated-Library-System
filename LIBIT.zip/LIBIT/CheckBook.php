<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['add'])) {
    if (empty($_POST['bname'])) {
        $_SESSION['msg'] = "Book Name Is Required";
        header("location: Book.php");
    } elseif (empty($_POST['iob'])) {
        $_SESSION['msg'] = "Book ID Is Required";
        header("location: Book.php");
    } elseif (empty($_POST['mlan'])) {
        $_SESSION['msg'] = "Access Number Is Required";
        header("location: Book.php");
    } elseif (empty($_POST['aob'])) {
        $_SESSION['msg'] = "Author Name is Required";
        header("location: Book.php");
    } elseif (empty($_POST['pob'])) {
        $_SESSION['msg'] = "Publication Name Is Required";
        header("location: Book.php");
    } elseif (empty($_POST['sob'])) {
        $_SESSION['msg'] = "Subject Name is Required";
        header("location: Book.php");
    } elseif (empty($_POST['dob'])) {
        $_SESSION['msg'] = "Details About Book Is Required";
        header("location: Book.php");
    } else {
        include('dbconnect.php');
        $bname = $_POST['bname'];
        $mlan = $_POST['mlan'];
        $iob = $_POST['iob'];
        $aob = $_POST['aob'];
        $pob = $_POST['pob'];
        $sob = $_POST['sob'];
        $dob = $_POST['dob'];
        $doa = date('Y-m-d h');
        $sts = "available";
        $stmt = $conn->prepare("INSERT INTO book VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sisssssss", $mlan, $iob, $bname, $aob, $sob, $pob, $dob, $doa, $sts);
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Successfully Added";
            header("location: Book.php");
        } else {
            $_SESSION['msg'] = "Adding Faild Please Enter Different Book ID Or Check Your Data";
            header("location: Book.php");
        }
    }
}
mysqli_close($conn);
?>   
