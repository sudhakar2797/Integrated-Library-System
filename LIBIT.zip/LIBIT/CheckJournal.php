<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['add'])) {
    if (empty($_POST['jname'])) {
        $_SESSION['msg'] = "Journal Title Is Required";
        header("location: Journal.php");
    } elseif (empty($_POST['ioj'])) {
        $_SESSION['msg'] = "Jornal ID is Required";
        header("location: Journal.php");
    } elseif (empty($_POST['yop'])) {
        $_SESSION['msg'] = "Year Of Publish Is Required";
        header("location: Journal.php");
    } else {
        include('dbconnect.php');
        $jname = $_POST['jname'];
        $ioj = $_POST['ioj'];
        $yop = $_POST['yop'];
        $doa = date('Y-m-d');
        $sts = "available";
        $stmt = $conn->prepare("INSERT INTO journal VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssss", $ioj, $jname, $yop, $doa, $sts);
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Successfully Added";
            header("location: Journal.php");
        } else {
            $_SESSION['msg'] = " Adding Faild Please Enter Different Journal ID Or Check Your Data";
            header("location: Journal.php");
        }
    }
}
?>   
