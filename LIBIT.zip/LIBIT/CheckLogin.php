<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$role = $_POST['role'];
if (empty($_POST['name']) || empty($_POST['password'])) {
    $_SESSION['msg'] = "Enter Username and Password";
    header("location: Index.php");
    ?>
    <script type="text/javascript">window.location = "Index.php";</script>
    <?php

} else if (empty($_POST['name']) && empty($_POST['password'])) {
    $_SESSION['msg'] = "Enter Username and Password";
    header("location: Index.php");
    ?>
    <script type="text/javascript">window.location = "Index.php";</script>
    <?php

} else {
    include("dbconnect.php");
    $name = $_POST['name'];
    $_SESSION['username'] = $name;
    $password = md5($_POST['password']);
    $sql = "SELECT * FROM login where name='$name' and password='$password'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $sql = "SELECT * FROM login where role='$role' AND name='$name'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            if ($role == "admin") {
                $_SESSION['GateWay'] = 'ADMIN';
                header("location: Panel.php");
                ?>
                <script type="text/javascript">window.location = "Panel.php";</script>
                <?php

            } else {
                $_SESSION['GateWay'] = 'OPEN';
                header("location: Home.php");
                ?>
                <script type="text/javascript">window.location = "Home.php";</script>
                <?php

            }
        } else {
            $_SESSION['msg'] = "Select Your Correct Role";
            header("location: Index.php");
            ?>
            <script type="text/javascript">window.location = "Index.php";</script>
            <?php

        }
    } else {
        $_SESSION['msg'] = "  Username or Password is Invalid";
        header("location: Index.php");
        ?>
        <script type="text/javascript">window.location = "Index.php";</script>
        <?php

    }
}
?>

