<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['add'])) {
    if (empty($_POST['mname'])) {
        $_SESSION['msg'] = "Manual Title Is Required";
        header("location: Manual.php");
    } elseif (empty($_POST['iom'])) {
        $_SESSION['msg'] = "Manual ID is Required";
        header("location: Manual.php");
    } elseif (empty($_POST['nol'])) {
        $_SESSION['msg'] = "Name Of Lab Is Required";
        header("location: Manual.php");
    } else {
        include('dbconnect.php');
        $mname = $_POST['mname'];
        $iom = $_POST['iom'];
        $nol = $_POST['nol'];
        $doa = date('Y-m-d');
        $sts = "avilable";
        $stmt = $conn->prepare("INSERT INTO manual VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssss", $iom, $mname, $nol, $doa, $sts);
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Successfully Added";
            header("location: Manual.php");
        } else {
            $_SESSION['msg'] = " Adding Faild, Please Enter Different Manual ID Or Check Your Data";
            header("location: Manual.php");
        }
    }
}
?>   
