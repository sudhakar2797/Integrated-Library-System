<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['add'])) {
    if (empty($_POST['pname'])) {
        $_SESSION['msg'] = "Project Name Is Required";
        header("location: Project.php");
    } elseif (empty($_POST['iop'])) {
        $_SESSION['msg'] = "Project ID Is Required";
        header("location: Project.php");
    } elseif (empty($_POST['aop'])) {
        $_SESSION['msg'] = " Area Of Project Is Required";
        header("location: Project.php");
    } elseif (empty($_POST['pdb'])) {
        $_SESSION['msg'] = "Developer Name Is Required";
        header("location: Project.php");
    } elseif (empty($_POST['pg'])) {
        $_SESSION['msg'] = "Guide Name is Required";
        header("location: Project.php");
    } elseif (empty($_POST['bat'])) {
        $_SESSION['msg'] = "Batch Detail Is Required";
        header("location: Project.php");
    } else {
        include('dbconnect.php');
        $pname = $_POST['pname'];
        $iop = $_POST['iop'];
        $aop = $_POST['aop'];
        $pdb = $_POST['pdb'];
        $pg = $_POST['pg'];
        $bat = $_POST['bat'];
        $doa = date('Y-m-d');
        $sts = "available";
        $stmt = $conn->prepare("INSERT INTO project VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param("ssssssss", $iop, $pname, $aop, $pdb, $pg, $bat, $doa, $sts);
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Successfully Added";
            header("location: Project.php");
        } else {
            $_SESSION['msg'] = "Adding Faild Please Enter Different Project ID Or Check Your Data";
            header("location: Project.php");
        }
    }
}
?>   
