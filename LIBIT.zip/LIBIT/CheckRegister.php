<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include("dbconnect.php");
$rname = $remail = $rrollno = $remail = "";

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function is_connected() {
    $connected = @fsockopen("www.google.com", 80);
    if ($connected) {
        $is_conn = true;
    } else {
        $is_conn = false;
    }
    return $is_conn;
}

if (isset($_POST['register'])) {
    $trole = $_POST['role'];
    if (empty($_POST['rname'])) {
        $_SESSION['rmsg'] = "Name Is Required";
        header("location: Register.php");
    } elseif (empty($_POST['rrollno'])) {
        $_SESSION['rmsg'] = "Roll Number Is Required";
        header("location: Register.php");
    } elseif (!(strpos($_POST['rrollno'], 'uite')) && ($trole == "student")) {
        $_SESSION['rmsg'] = "Please Enter Correct Roll Number";
        header("location: Register.php");
    } elseif (empty($_POST['remail'])) {
        $_SESSION['rmsg'] = "Email Is Required";
        header("location: Register.php");
    } elseif ((!empty($_POST['remail'])) && (!filter_var($_POST['remail'], FILTER_VALIDATE_EMAIL))) {
        $_SESSION['rmsg'] = "Invalid Email Format";
        header("location: Register.php");
    } elseif ((strpos($_POST['rrollno'], 'uite')) && ($trole != "student")) {
        $_SESSION['rmsg'] = "Please Select Your Correct Role";
        header("location: Register.php");
    } else {
        $name = $_POST['rname'];
        $rollno = $_POST['rrollno'];
        $is_conn = is_connected();
        if ($is_conn) {
            $stmt = $conn->prepare("INSERT INTO register  VALUES (?,?,?,?,?)");
            $stmt->bind_param("sssss", $name, $rollno, $role, $email, $dateofadd);
            $role = $_POST['role'];
            $email = $_POST['remail'];
            $dateofadd = date('Y-m-d');
            $password = mt_rand(100000, 999999);
            $dpassword = md5($password);
            $stmt1 = $conn->prepare("INSERT INTO login VALUES (?,?,?)");
            $stmt1->bind_param("sss", $rollno, $dpassword, $role);
            if (($stmt->execute()) && ($stmt1->execute())) {
                $subject = "Thank You";
                require 'config.php';
                $message = "
        <html>
        <body style='width: 500px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>
        <div style= 'background-color: #357ae8;width: 500px; height:100px;top:0px;position: absolute;'><p style='color:white; font-size:25px;font-family:calibre;text-align: center;'><br>Department Library<br><br><br></div>
        <center><strong><br><br><br><br><pre style=' font-size:20px;font-family:calibre;'> 
              You Have Been Successfully Registered
           !!!!...Welcome To Department Library...!!!!
<p style='color:orangered; font-size:25px;font-family:calibre;text-align: center;'>UserName</p>                                  
" . $rollno . " 
<p style='color:orangered; font-size:25px;font-family:calibre;text-align: center;'>Password</p>                                  
" . $password . "
<p style='color:orangered; font-size:25px;font-family:calibre;text-align: center;'>Click Here To Visit Our Library</p>      
" . $url . "
    </pre>
                                                    </strong>
                                        </center>
                                    </body>
                                </html>";
                ;
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: ' . $registerfrom . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();
                $message = wordwrap($message, 70);
                $result = mail($email, $subject, $message, $headers);
                if ($result) {
                    header("location: Index.php");
                } else {
                    $_SESSION['rmsg'] = "Please Try Again";
                    header("location: Register.php");
                }
            } else {
                $_SESSION['rmsg'] = "Please Enter Valid Data";
                header("location: Register.php");
            }
        } else {
            $_SESSION['rmsg'] = "Check Your Internet Connection";
            header("location: Register.php");
        }
        $stmt->close();
        $conn->close();
    }
}
?>        