<?php

//Registration  page URL Send To Mail (page:bulkuser.php)
$url = "http://localhost/LIBIT/Index.php";

$furl = "http://localhost/LIBIT/Reset.php";
//used in forgot password page for reset page

$registerfrom = "sudhakar.it.12345@gmail.com";

$dbh = new PDO("mysql:host=localhost;dbname=library", 'root', '');
// used by PhotoTOGallery page 
//Insert Image In Database

$FilePath='questions\\';


?>