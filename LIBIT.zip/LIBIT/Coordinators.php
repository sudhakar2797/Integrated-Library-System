<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <?php
        require 'dbconnect.php';
        $msg = "";
        if (isset($_POST['update'])) {
            $first = $_POST['first'];
            $second = $_POST['second'];
            $third = $_POST['third'];
            $final = $_POST['final'];
            $sql = "UPDATE `coordinators` SET `firstyear`='$first',`secondyear`='$second',`thirdyear`='$third',`finalyear`='$final' WHERE 1";
            if ($conn->query($sql)) {
                $msg = " Successfully updated";
            } else {
                $msg = " Please Try Again";
            }
        }
        ?><!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-edit"></i> &nbsp;Coordinators&nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-12 main-chart">		
                                    <div class="col-lg-9 col-md-12 col-sm-12"> 
                                        <?php if (!empty($msg)) { ?>
                                            <h4 class="alert alert-success">
                                                <?php echo $msg; ?>
                                                <span class="closebtn">&times;</span>  
                                                <script>
                                                    var close = document.getElementsByClassName("closebtn");
                                                    var i;

                                                    for (i = 0; i < close.length; i++) {
                                                        close[i].onclick = function () {
                                                            var div = this.parentElement;
                                                            div.style.opacity = "0";
                                                            setTimeout(function () {
                                                                div.style.display = "none";
                                                            }, 600);
                                                        }
                                                    }
                                                </script></h4><?php } ?>
                                        <div class="showback" style="color:#000">
                                            <link href="assets/css/bcss.css" rel="stylesheet">
                                            <form action="Coordinators.php" method="post">
                                                <center>
                                                    <h3 class="fa fa-2x">
                                                        <i class="fa fa-edit"></i>&nbsp;&nbsp;&nbsp;Update Data
                                                    </h3>
                                                </center>
                                                <?php
                                                require 'dbconnect.php';
                                                $sql = "SELECT * FROM coordinators";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $dfirst = $row['firstyear'];
                                                        $dsecond = $row['secondyear'];
                                                        $dthird = $row['thirdyear'];
                                                        $dfinal = $row['finalyear'];
                                                    }
                                                }
                                                ?>
                                                <label><b>First Year&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                <input type="text" name="first" value="<?php
                                                if (isset($dfirst)) {
                                                    echo $dfirst;
                                                }
                                                ?>"/><br><br>

                                                <label><b>Second Year&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                <input type="text" name="second" value="<?php
                                                if (isset($dsecond)) {
                                                    echo $dsecond;
                                                }
                                                ?>"/><br><br>

                                                <label><b>Third Year&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                <input type="text" name="third" value="<?php
                                                if (isset($dthird)) {
                                                    echo $dthird;
                                                }
                                                ?>"/><br><br>

                                                <label><b>Final Year&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                <input type="text" name="final" value="<?php
                                                if (isset($dfinal)) {
                                                    echo $dfinal;
                                                }
                                                ?>"/><br><br>

                                                <center><button class="btn btn-primary fa-1x" name="update"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <a href="Panel.php"><button type="button"  class="btn btn-danger fa-1x"><i class="fa fa-trash-o"></i>&nbsp;&nbsp;Cancel</button></a>
                                                </center>
                                            </form>
                                        </div>
                                    </div>
                                    <?php include 'Links/Topers.php'; ?>
                                </div>
                            </div>
                        </section>
                    </section>
                    <!--main content end--><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
