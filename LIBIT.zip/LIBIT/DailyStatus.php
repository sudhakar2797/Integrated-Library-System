<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Book&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-12 col-md-12 col-sm-12 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000;">
                                            <?php if (!empty($_SESSION['error'])) { ?>
                                                <h4 class="alert alert-success">
                                                    <?php echo $_SESSION['error']; ?>
                                                    <span class="closebtn">&times;</span>  
                                                    <script>
                                                        var close = document.getElementsByClassName("closebtn");
                                                        var i;

                                                        for (i = 0; i < close.length; i++) {
                                                            close[i].onclick = function () {
                                                                var div = this.parentElement;
                                                                div.style.opacity = "0";
                                                                setTimeout(function () {
                                                                    div.style.display = "none";
                                                                }, 600);
                                                            }
                                                        }
                                                    </script></h4><?php } ?><?php
                                            if (!empty($_SESSION['error'])) {
                                                unset($_SESSION['error']);
                                            }
                                            ?>
                                            <link href="assets/css/today.css" rel="stylesheet">
                                            <?php
                                            echo'<table>';
                                            echo'<thead>';
                                            echo'<tr>';
                                            echo'<th>BookID</th>';
                                            echo'<th>RollNumber</th>';
                                            echo'<th>Name</th>';
                                            echo'<th>year</th>';
                                            echo'<th>Date Of Reserve</th>';
                                            echo'<th>Status</th>';
                                            echo'</tr>';
                                            echo'</thead>';
                                            echo'<tbody>';
                                            require 'dbconnect.php';
                                            $query = "SELECT * FROM booking WHERE status='pending' ";
                                            $query1 = "SELECT * FROM booking WHERE status='pending' ";
                                            $sql = $conn->query($query);
                                            if ($sql->num_rows > 0) {
                                                while ($row = $sql->fetch_assoc()) {
                                                    ?>
                                                    <tr>
                                                        <td style="color:maroon" class="user-name">
                                                            <?php echo $row['id']; ?>
                                                        </td>
                                                        <td style="color:maroon" class="user-name">
                                                            <?php echo $row['rollno']; ?>
                                                        </td>
                                                        <td class="user-name">
                                                            <?php echo $row['name']; ?>
                                                        </td>
                                                        <td class="user-phone">
                                                            <?php echo $row['year']; ?>
                                                        </td>
                                                        <td class="user-phone">
                                                            <?php echo $row['dateofrequest']; ?>
                                                        </td>  
                                                        <td class="user-name">
                                                            <form method="post" action="GrantBook.php">
                                                                <input type="text" name="BookID" value="<?php echo $row['id']; ?>" class="display hidden">
                                                                <input type="text" name="uid" value="<?php echo $row['rollno']; ?>" class="display hidden">
                                                                <button class="but1">
                                                                    <span>Grant</span>
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {
                                                echo'<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                                            }
                                            echo'</tbody>';
                                            echo'</table>';
                                            ?> 
                                        </div>              
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end--><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
