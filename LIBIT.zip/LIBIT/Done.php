<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['update'])) {
    require 'dbconnect.php';
    $rollno = $_SESSION['rollno'];
    $bookid = $_SESSION['libid'];
    $bookname = $_SESSION['title'];
    $author = $_SESSION['author'];
    $issuedate = $_SESSION['issuedate'];
    $returndate = $_SESSION['returndate'];
    $status = "granted";
    $year = $_SESSION['year'];
    $semester = $_SESSION['semester'];
    $stmt = $conn->prepare("INSERT INTO transaction  VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssssss", $rollno, $bookid, $bookname, $author, $issuedate, $returndate, $status, $semester, $year);
    if ($stmt->execute()) {
        $query1 = "SELECT * FROM book WHERE id='$bookid' AND status='available'";
        $sql1 = $conn->query($query1);
        $query2 = "SELECT * FROM project WHERE id='$bookid' AND status='available'";
        $sql2 = $conn->query($query2);
        $query3 = "SELECT * FROM manual WHERE id='$bookid' AND status='available'";
        $sql3 = $conn->query($query3);
        $query4 = "SELECT * FROM journal WHERE id='$bookid' AND status='available'";
        $sql4 = $conn->query($query4);
        if ($sql1->num_rows > 0) {
            $sql = "UPDATE booking SET status='accepted' WHERE id='$bookid' and rollno='$rollno'";
            $sql1 = "UPDATE book SET status='notavailable' WHERE id='$bookid'";
            if ((mysqli_query($conn, $sql)) && (mysqli_query($conn, $sql1))) {
                $query = "DELETE  FROM booking WHERE id='$bookid'";
                if ($conn->query($query)) {
                    $_SESSION['error'] = "Book Granted";
                    include 'DailyStatus.php';
                } else {
                    $_SESSION['error'] = "please Try Again";
                    include 'DailyStatus.php';
                }
            } else {
                $_SESSION['error'] = "please Try Again";
                include 'DailyStatus.php';
            }
        } elseif ($sql2->num_rows > 0) {
            $sql = "UPDATE booking SET status='accepted' WHERE id='$bookid' and rollno='$rollno'";
            $sql1 = "UPDATE project SET status='notavailable' WHERE id='$bookid'";
            if ((mysqli_query($conn, $sql)) && (mysqli_query($conn, $sql1))) {
                $query = "DELETE  FROM booking WHERE id='$bookid'";
                if ($conn->query($query)) {
                    $_SESSION['error'] = "Book Granted";
                    include 'DailyStatus.php';
                } else {
                    $_SESSION['error'] = "please Try Again";
                    include 'DailyStatus.php';
                }
            } else {
                $_SESSION['error'] = "please Try Again";
                include 'DailyStatus.php';
            }
        } elseif ($sql3->num_rows > 0) {
            $sql = "UPDATE booking SET status='accepted' WHERE id='$bookid' and rollno='$rollno'";
            $sql1 = "UPDATE manual SET status='notavailable' WHERE id='$bookid'";
            if ((mysqli_query($conn, $sql)) && (mysqli_query($conn, $sql1))) {
                $query = "DELETE  FROM booking WHERE id='$bookid'";
                if ($conn->query($query)) {
                    $_SESSION['error'] = "Book Granted";
                    include 'DailyStatus.php';
                } else {
                    $_SESSION['error'] = "please Try Again";
                    include 'DailyStatus.php';
                }
            } else {
                $_SESSION['error'] = "please Try Again";
                include 'DailyStatus.php';
            }
        } elseif ($sql4->num_rows > 0) {
            $sql = "UPDATE booking SET status='accepted' WHERE id='$bookid' and rollno='$rollno'";
            $sql1 = "UPDATE journal SET status='notavailable' WHERE id='$bookid'";
            if ((mysqli_query($conn, $sql)) && (mysqli_query($conn, $sql1))) {
                $query = "DELETE  FROM booking WHERE id='$bookid'";
                if ($conn->query($query)) {
                    $_SESSION['error'] = "Book Granted";
                    include 'DailyStatus.php';
                } else {
                    $_SESSION['error'] = "please Try Again";
                    include 'DailyStatus.php';
                }
            } else {
                $_SESSION['error'] = "please Try Again";
                include 'DailyStatus.php';
            }
        }
    } else {
        $_SESSION['error'] = "please Try Again";
        include 'DailyStatus.php';
    }
}
?>


