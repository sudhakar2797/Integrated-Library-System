<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
    <?php include 'Links/CSS.php'; ?>
    <body>
        <section id="container" >
            <?php include 'Links/Navigation.php'; ?>
            <?php include 'Links/WelcomeMenu.php'; ?>
            <!-- **********************************************************************************************************************************************************
            MAIN CONTENT
            *********************************************************************************************************************************************************** -->
            <!--main content start-->
            <section id="main-content">
                <section class="wrapper">
                    <div class="row" style="color:#000;">
                        <link rel="stylesheet" type="text/css" href="assets/css/icss.css">
                        <h3 style="color:#000">&nbsp;<i class="fa fa-key"></i> &nbsp;Forgot Password&nbsp;&nbsp;<a href="Index.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                        <div class="col-lg-9 main-chart">		
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <br><br><br><br>
                                <?php if (!empty($_SESSION['fmsg'])) { ?>
                                    <link href="assets/css/alert.css" rel="stylesheet" />
                                    <h4 class="alert alert-info">
                                        <?php echo $_SESSION['fmsg']; ?>
                                        <span class="closebtn">&times;</span>  
                                        <script>
                                            var close = document.getElementsByClassName("closebtn");
                                            var i;

                                            for (i = 0; i < close.length; i++) {
                                                close[i].onclick = function () {
                                                    var div = this.parentElement;
                                                    div.style.opacity = "0";
                                                    setTimeout(function () {
                                                        div.style.display = "none";
                                                    }, 600);
                                                }
                                            }
                                        </script></h4><?php } ?>
                                <div class="showback">
                                    <h3><i class="fa fa-key"></i> &nbsp;Forgot password</h3><br>
                                    <form name="f1" action="ForgotPD.php" method="post">
                                        <input type="text" name="femail" placeholder="Enter Your Email Address" required>
                                        <input type="submit" name="login" class="login login-submit" value="Send an Email">
                                        <center><h4 class="message"> <a href="Reset.php" class="s">Reset Password</a></h4></center>
                                    </form>
                                    <?php
                                    if (!empty($_SESSION['fmsg'])) {
                                        unset($_SESSION['fmsg']);
                                    }
                                    ?>
                                </div>	
                            </div><!-- /col-lg-9 END SECTION MIDDLE -->
                        </div>
                        <?php include 'Links/Topers.php'; ?>
                    </div><! --/row -->
                </section>
            </section>
            <!--main content end-->
            <?php include 'Links/Footer.php'; ?>
            <?php
            date_default_timezone_set('Asia/Calcutta');
            $Hour = date('G');
            $time = "";
            if ($Hour >= 5 && $Hour <= 11) {
                $time = "Good Morning";
            } else if ($Hour >= 12 && $Hour <= 18) {
                $time = "Good Afternoon";
            } else if ($Hour >= 19 || $Hour <= 4) {
                $time = "Good Evening";
            }
            ?>
        </section>
        <!-- js placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/jquery-1.8.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="assets/js/jquery.sparkline.js"></script>
        <!--common script for all pages-->
        <script src="assets/js/common-scripts.js"></script>
        <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
        <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        <!--script for this page-->
        <script src="assets/js/sparkline-chart.js"></script>    
        <script src="assets/js/zabuto_calendar.js"></script>	
        <script type="text/javascript">
                                            $(document).ready(function () {
                                                var unique_id = $.gritter.add({
                                                    // (string | mandatory) the heading of the notification
                                                    title: 'Welcome to LIB-IT',
                                                    // (string | mandatory) the text inside the notification
                                                    text: '<?php echo $time; ?>',
                                                    // (string | optional) the image to display on the left
                                                    image: 'assets/img/logo.png',
                                                    // (bool | optional) if you want it to fade out on its own or just sit there
                                                    sticky: true,
                                                    // (int | optional) the time you want it to be alive for before fading out
                                                    time: '',
                                                    // (string | optional) the class name you want to apply to that specific message
                                                    class_name: 'my-sticky-class'
                                                });
                                                return false;
                                            });
        </script>
    </body>
</html>
