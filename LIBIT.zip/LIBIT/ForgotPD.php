<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include("dbconnect.php");
$femail = test_input($_POST['femail']);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (empty($_POST["femail"])) {
        $_SESSION['fmsg'] = "Email Is Required";
        header("location: Forgot.php");
    } else if (!filter_var($femail, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['fmsg'] = "Invalid Email Format";
        header("location: Forgot.php");
    } else {
        $sql = "SELECT rollno FROM register where emailid='$femail'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $name = $row['rollno'];
            $sql1 = "SELECT password FROM login where name='$name'";
            $result1 = $conn->query($sql1);
            if ($result1->num_rows > 0) {
                $row1 = $result1->fetch_assoc();
                $fpassword = $row1["password"];
            } else {
                $_SESSION['fmsg'] = " Please try Again";
                header("location: Forgot.php");
            }
        } else {
            $_SESSION['fmsg'] = " Please Enter Registered Email";
            header("location: Forgot.php");
        }
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function is_connected() {
    $connected = @fsockopen("www.google.com", 80);
    if ($connected) {
        $is_conn = true;
    } else {
        $is_conn = false;
    }
    return $is_conn;
}

$is_conn = is_connected();
if ($is_conn) {
    $subject = "Forgot password?";
    require 'Config.php';
    $message = " 
<html>
    <head>
        <title>Department Library Login</title>
    </head>
    <body>
    <center>	
        <div style='border:3px solid blue;width:70%;background-color:#fff;'>
            <p style='color:#000;font-size:20px'><strong>!!!!...Department Library...!!!!<br>
                    <p style='color:#357ae8;'><strong>Your Password Have Been Changed</strong></p>
                    <p style='color:#000;'><strong>Your New Password &nbsp;&nbsp; </strong><span style='color:purple;'> " . $fpassword . "</span></p>
                    <p style='color:#000;'><strong>Click Here To Reset Your Password</strong><br><span style='color:357ae8'> " . $furl . "</span></p>
        </div>
    </center>                        
</body>
</html> ";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $result = mail($femail, $subject, $message, $headers);
    if ($result) {
        header("location: Reset.php");
    } else {
        $_SESSION['fmsg'] = " Please try Again";
        header("location: Forgot.php");
    }
} else {
    $_SESSION['fmsg'] = "Check Your Internet Connection";
    header("location: Forgot.php");
}
$conn->close();
?>        