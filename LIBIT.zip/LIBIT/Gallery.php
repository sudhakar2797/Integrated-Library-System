<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper site-min-height">
                        <h3><i class="fa fa-photo"></i> Gallery&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                        <hr>
                        <?php
                        require 'dbconnect.php';
                        $sql = "SELECT * FROM gallery ";
                        $sth = $conn->query($sql);
                        while ($result = mysqli_fetch_array($sth)) {
                            ?>

                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 desc"><div class="showback" style="width: 200px;height: 200px ;border-bottom: 20px;border-color:#fff;">
                                    <div class="project-wrapper" >
                                        <div class="project">
                                            <div class="photo-wrapper">
                                                <div class="photo">
                                                    <form action="PhotoZoom.php" method="post" enctype="multipart/form-data">
                                                        <button style="background-color: #fff;border: none " name="zoom" class="fancybox" >

                                                            <?php
                                                            echo '<img class="img-responsive" src="data:image/jpeg;base64,' . base64_encode($result['image']) . '"/>';
                                                            $id = $result['image_id'];
                                                            ?>

                                                            <input type="text" class="hidden" name="imageid" value="<?php echo $id; ?>" />
                                                        </button> </form>
                                                </div>
                                                <div class="overlay"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div></div>
                        <?php } ?>
                        </div><!-- /row -->
                    </section><! --/wrapper -->
                </section>
                <!--main content end-->
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>