<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])){
$error = "";
$flag = 0;

require 'dbconnect.php';
$bookid = $_POST['BookID'];
$uid = $_POST['uid'];
$query1 = "SELECT * FROM book WHERE id='$bookid' AND status='available'";
$sql1 = $conn->query($query1);
$query2 = "SELECT * FROM project WHERE id='$bookid' AND status='available'";
$sql2 = $conn->query($query2);
$query3 = "SELECT * FROM manual WHERE id='$bookid' AND status='available'";
$sql3 = $conn->query($query3);
$query4 = "SELECT * FROM journal WHERE id='$bookid' AND status='available'";
$sql4 = $conn->query($query4);
if ($sql1->num_rows > 0) {
    $flag = 1;
    while ($row1 = $sql1->fetch_assoc()) {
        $_SESSION['title'] = $row1['title'];
        $_SESSION['author'] = $row1['author'];
    }
} elseif ($sql2->num_rows > 0) {
    $flag = 1;
    while ($row2 = $sql2->fetch_assoc()) {
        $_SESSION['title'] = $row2['title'];
        $_SESSION['author'] = $row2['by'];
    }
} elseif ($sql3->num_rows > 0) {
    $flag = 1;
    while ($row3 = $sql3->fetch_assoc()) {
        $_SESSION['title'] = $row3['title'];
        $_SESSION['author'] = $row3['labname'];
    }
} elseif ($sql4->num_rows > 0) {
    $flag = 1;
    while ($row4 = $sql4->fetch_assoc()) {
        $_SESSION['title'] = $row4['title'];
        $_SESSION['author'] = $row4['yearofpublish'];
    }
} 
if ($flag == 1) {
    $query = "SELECT * FROM booking WHERE id='$bookid' AND rollno='$uid'";
    $sql = $conn->query($query);
    if ($sql->num_rows > 0) {
        while ($row = $sql->fetch_assoc()) {
            $_SESSION['libid'] = $row['id'];
            $_SESSION['rollno'] =$row['rollno'];
            $_SESSION['name'] =$row['name'];
            $_SESSION['year'] = $row['year'];
            $_SESSION['semester'] = $row['semester'];
            $_SESSION['issuedate'] = date('Y-m-d');
            $date = date_create($_SESSION['issuedate']);
            date_add($date, date_interval_create_from_date_string("14 days"));
            $_SESSION['returndate'] =date_format($date, "Y-m-d");
        }
    }
}else {
                $_SESSION['error'] = "Book Not Available";
                include 'DailyStatus.php';
            }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include 'Links/CSS.php'; ?>
    <body>
        <section id="container" >
            <?php include 'Links/Navigation.php'; ?>
            <?php include 'Links/Menu.php'; ?>
            <!-- **********************************************************************************************************************************************************
            MAIN CONTENT
            *********************************************************************************************************************************************************** -->
            <!--main content start-->
            <section id="main-content">
                <section class="wrapper">
                    <div class="row">
                        <h3 style="color:#000">&nbsp;<i class="fa fa-shield"></i>&nbsp; &nbsp;Grant Book&nbsp;&nbsp; <a href="DailyStatus.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                        <div class="col-lg-9 main-chart">		
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="showback">
                                    <div class="content-panel">
                                        <form method="post" action="Done.php" >
                                            <table class="table table-striped table-advance table-hover">
                                                <center> 
                                                    <h4><i class="fa fa-key"></i>&nbsp;User And Book Details</h4>
                                                </center><hr>
                                                <thead>
                                                    <tr>
                                                        <th width="22%"><h6><i class="fa fa-bolt"></i>&nbsp;Category<h6></th>
                                                                    <th><h6><i class="fa fa-bar-chart-o"></i>&nbsp;Data</th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp; Name</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp;<?php echo $_SESSION['name']; ?> </h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp; Roll No</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp;<?php echo $_SESSION['rollno']; ?> </h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Issue Date</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp; <?php echo $_SESSION['issuedate']; ?> </h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Return Date</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp;<?php echo $_SESSION['returndate']; ?></h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Book ID</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp; <?php echo $_SESSION['libid']; ?> </h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Book Name</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp; <?php echo $_SESSION['title']; ?>  </h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Author Name</h6></td>
                                                                            <td><h6><i class="fa fa-exchange"></i>&nbsp; <?php echo $_SESSION['author']; ?></h6></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td></td>
                                                                            <td> 
                                                                    <center>  
                                                                        <button class="btn btn-success  fa-1x" name="update" ><i class="fa fa-leaf"></i>&nbsp;Grant</button> 
                                                                    </center> 
                                                                    </td>
                                                                    </tr>
                                                                    </tbody>
                                                                    </table>
                                        </form>
                                    </div><!-- /content-panel -->
                                </div>
                            </div>
                        </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            <?php include 'Links/Topers.php'; ?>
                    </div><! --/row -->
                </section>
            </section>
                                                                    <!--main content end-->
            <?php include 'Links/Footer.php'; ?>
        </section>
                                                                    <!-- js placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/jquery-1.8.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="assets/js/jquery.sparkline.js"></script>
        <!--common script for all pages-->
        <script src="assets/js/common-scripts.js"></script>
        <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
        <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
    </body>
</html>
<?php
} else {
    header("location:Index.php");
}?>