<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-heart"></i> &nbsp;Help&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="showback">
                                        <div style="color: #000"><center> <i class="fa fa-info-circle fa-5x"></i>
                                                <br><br><br><br>
                                                <h3 >  <i class="fa fa-key fa-2x"></i> Please contact Library Coordinator  <br><br>      
                                                    <br><br></h3> </center>
                                        </div>      
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            </div>
                            <?php include 'Links/Topers.php'; ?>
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end-->
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>