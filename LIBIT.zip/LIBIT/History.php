<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-clock-o"></i> &nbsp;History&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-12 main-chart">		
                                <div class="col-lg-6 col-md-12 col-sm-12">                                
                                    <div class="showback" style="color:#000">
                                        <link href="assets/css/bcss.css" rel="stylesheet">
                                        <form action="History.php" method="post">
                                            <center>
                                                <h3 class="fa fa-2x">
                                                    <i class="fa fa-clock-o"></i>&nbsp;&nbsp;&nbsp;View History
                                                </h3>
                                            </center>
                                           <br><center> <label><b>Roll Number&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                            <input type="text" name="rollno" placeholder="Enter your Roll NO"/><br>
                                            <br><button class="btn btn-primary fa-1x" name="view"><i class="fa fa-edit"></i>&nbsp;&nbsp;View</button>
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a href="Home.php"><button type="button"  class="btn btn-danger fa-1x"><i class="fa fa-trash-o"></i>&nbsp;&nbsp;Cancel</button></a>
                                            </center>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <link href="assets/css/component.css" rel="stylesheet">
                                    <?php
                                    if (isset($_POST['view'])) {
                                        if (empty($_POST['rollno'])) {
                                            echo'<center><h3 style="font-style:bold;">Enter Anything To Display...</h3></center>';
                                        } else {
                                            echo '<div class="showback" style="color:#000;">';
                                            echo'<table>';
                                            echo'<thead>';
                                            echo'<tr>';
                                            echo'<th>BookId</th>';
                                            echo'<th>Title</th>';
                                            echo'<th>Author Name</th>';
                                            echo'<th>Issue Date</th>';
                                            echo'<th>EXP-ReturnDate</th>';
                                            echo'<th>Return Status</th>';
                                            echo'</tr>';
                                            echo'</thead>';
                                            echo'<tbody>';
                                            $word = $_POST['rollno'];
                                            require 'dbconnect.php';

                                            $query = "SELECT * FROM transaction WHERE id = '$word'";
                                            $sql = $conn->query($query);
                                            if ($sql->num_rows > 0) {
                                                while ($row = $sql->fetch_assoc()) {
                                                    ?>
                                                    <tr>
                                                        <td style="color:#f67854" class="user-name">
                                                            <?php echo $row['bookid']; ?>
                                                        </td>
                                                        <td class="user-name">
                                                            <?php echo $row['bookname'] ?>
                                                        </td>
                                                        <td class="user-phone">
                                                            <?php echo $row['author'] ?>
                                                        </td> 
                                                        <td class="user-name">                     
                                                            <?php echo $row['issuedate'] ?>                                 
                                                        </td>
                                                        <td class="user-name">                     
                                                            <?php echo $row['returndate'] ?>                                 
                                                        </td>
                                                        <?php if ($row['status'] == 'granted') { ?>
                                                            <td class="user-name" style="color:red">
                                                                <i class="fa fa-thumbs-down"></i>&nbsp;
                                                                <i class="fa fa-bell"></i>
                                                            </td><?php } else if ($row['status'] == 'returned') { ?>
                                                            <td class="user-name" style="color:green">
                                                                <i class="fa fa-thumbs-up"></i>&nbsp;
                                                                <i class="fa fa-bell"></i>

                                                            </td><?php } ?>
                                                    </tr>                             

                                                    <?php
                                                }
                                            } else {
                                                echo '<tr ><td colspan="6" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                            }
                                        }

                                        echo' </tbody>';
                                        echo' </table>';
                                        echo' </div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </section>
                </section>
                <!--main content end--><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>