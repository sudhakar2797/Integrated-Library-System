<ul class="dropdown-menu extended tasks-bar">
    <div class="notify-arrow notify-arrow-green"></div>
    <li>
        <p class="green">
            Your Holding Books
        </p>
    </li>
    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    } require 'dbconnect.php';
    if (isset($_SESSION['GateWay'])) {
        $uid = $_SESSION['username'];
        $query = "SELECT bookname FROM transaction where status='granted' and id ='$uid'";
        $sql = $conn->query($query);
        if ($sql->num_rows > 0) {
            while ($row = $sql->fetch_assoc()) {
                ?>
                <li>
                    <a href="#">
                        <div class="task-info">
                            <div class="desc">
                                <?php
                                echo $row['bookname'];
                                ?>
                            </div>
                        </div>
                    </a>
                </li>
                <?php
            }
        } else {
            ?>
            <li>
                <a href="#">
                    <div class="task-info">
                        <div class="desc">
                            No Data Available 
                        </div>
                    </div>
                </a>
            </li>
            <?php
        }
    } else {
        ?>
        <li>
            <a href="#">
                <div class="task-info">
                    <div class="desc">
                        No Data Available Login & Try
                    </div>
                </div>
            </a>
        </li>
    <?php } ?>
</ul>