<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Journal&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback">
                                            <style>
                                                .ui-datepicker-calendar {
                                                    display: none;
                                                }
                                                input[type=date] {
                                                    width: 190px;
                                                    height:44px;
                                                    box-sizing: border-box;
                                                    border: 2px solid #ccc;
                                                    border-radius: 4px;
                                                    font-size: 16px;
                                                    background-color: white;
                                                    background-repeat: no-repeat;
                                                    padding: 12px 20px 8px 45px;
                                                    -webkit-transition: width 0.4s ease-in-out;
                                                    transition: width 0.4s ease-in-out;
                                                }
                                                input[type=date]:focus {
                                                    width: 45%;
                                                }
                                            </style> 
                                            <center>  
                                                <br>
                                                <h3 style="color:#000;">  Journal Availability Report</h3>
                                                <form method="get" action="JournalAvailableReportPDF.php">
                                                    <center><image src="assets/img/image/report4.jpg" width="120px" height="120px"/></center><br>
                                                    <br>
                                                    <button class="btn btn-primary fa-1x" name="showme"><i class="fa fa-laptop"></i>&nbsp;Show Me</button>      
                                                </form><br>
                                            </center>     
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
