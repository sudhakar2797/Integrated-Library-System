<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Journal&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-12 main-chart">		
                                    <div class="col-lg-6 col-md-6 col-sm-6 ">
                                        <div class="showback" style="color:#000;">
                                            <style>
                                                input[type=date] {
                                                    width: 190px;
                                                    height:38px;
                                                    box-sizing: border-box;
                                                    border: 2px solid #ccc;
                                                    border-radius: 4px;
                                                    font-size: 14px;
                                                    background-color: white;
                                                    background-repeat: no-repeat;
                                                    padding: 8px 16px 8px 40px;
                                                    -webkit-transition: width 0.4s ease-in-out;
                                                    transition: width 0.4s ease-in-out;
                                                }
                                            </style>
                                            <link href="assets/css/component.css"rel="stylesheet">
                                            <center style="color:#000;">  
                                                <h4 > Journal Display</h4>
                                                <form method="post" action="JournalDisplay.php">
                                                    <center><image src="assets/img/image/displaybook.png" width="100px" height="100px"/></center><br>
                                                    <input  style="background-image:url(assets/img/image/from.png);" type="date" id="datepicker1" placeholder="    From Date..." name="from" required>
                                                    <input style="background-image:url(assets/img/image/to.png);"  type="date" id="datepicker2" placeholder="    To Date..." name="to" required><br><br>
                                                    <button class="btn btn-primary fa-1x" name="showme"><i class="fa fa-laptop"></i>&nbsp;Show Me</button>      
                                                </form><br>
                                            </center></div></div></div>
                                <div class="col-lg-12 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <?php
                                        if (isset($_POST['showme'])) {
                                            if (empty($_POST['from'])) {
                                                echo'<center><h3 style="font-style:bold;">Please Choose From Date</h3></center>';
                                            } elseif (empty($_POST['to'])) {
                                                echo'<center><h3 style="font-style:bold;">Please Choose To Date</h3></center>';
                                            } else {
                                                echo '<div class="showback" style="color:#000;">';
                                                echo'<table>';
                                                echo'<thead>';
                                                echo'<tr>';
                                                echo'<th>JournalId</th>';
                                                echo'<th>Title</th>';
                                                echo'<th> Published Year</th>';
                                                echo'<th>Status</th>';
                                                echo'</tr>';
                                                echo'</thead>';
                                                echo'<tbody>';
                                                $from = $_POST['from'];
                                                $old = strtotime($from);
                                                $from = date('Y-m-d ', $old);
                                                $to = $_POST['to'];
                                                $old = strtotime($to);
                                                $to = date('Y-m-d ', $old);
                                                require 'dbconnect.php';
                                                $query = "SELECT * FROM journal WHERE dateofadd >= '$from' AND dateofadd <='$to';";
                                                $sql = $conn->query($query);
                                                if ($sql->num_rows > 0) {
                                                    while ($row = $sql->fetch_assoc()) {
                                                        if ($row['status'] == "available") {
                                                            echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['yearofpublish'] . '</td><td style="color:green;font-size:16px;font-family:calibri;" class="user-name">Available</td> </tr>';
                                                        } else {
                                                            echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['yearofpublish'] . '</td><td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                        }
                                                    }
                                                } else {
                                                    echo '<tr><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                }
                                            }
                                        }
                                        echo' </tbody>';
                                        echo' </table>';
                                        echo'   </div>';
                                        ?>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end--><br><br><br><br><br><br><br><br>
                    <?php include 'Links/Footer.php'; ?>
                    <!-- js placed at the end of the document so the pages load faster -->
                    <script src="assets/js/jquery.js"></script>
                    <script src="assets/js/jquery-1.8.3.min.js"></script>
                    <script src="assets/js/bootstrap.min.js"></script>
                    <!--common script for all pages-->
                    <script src="assets/js/common-scripts.js"></script>
                    <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
                    <link rel="stylesheet" href="jq/jquery-ui.css">
                    <script src="jq/jquery.js"></script>
                    <script src="jq/jquery-ui.js"></script>
                    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                    <script src="assets/js/jquery.scrollTo.min.js"></script>
                    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                    <script src="assets/js/jquery.sparkline.js"></script>
                    <script>
                        $(function () {
                            $("#datepicker").datepicker();
                            $("#format").on("change", function () {
                                $("#datepicker").datepicker("option", "dateFormat", $(this).val());
                            });
                        });
                        $(function () {
                            $("#datepicker1").datepicker();
                            $("#format").on("change", function () {
                                $("#datepicker1").datepicker("option", "dateFormat", $(this).val());
                            });
                        });
                        $(function () {
                            $("#datepicker2").datepicker();
                            $("#format").on("change", function () {
                                $("#datepicker1").datepicker("option", "dateFormat", $(this).val());
                            });
                        });
                    </script>	
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
