<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><?php
    $_SESSION['error'] = $_SESSION['error'] = "";
    if (isset($_POST['reserve'])) {
        require 'dbconnect.php';
        $id = $_POST['journalid'];
        $rollno = $_POST['rollno'];
        $semester = $_POST['sem'];
        $year = $_POST['year'];
        $sql = "SELECT * FROM journal where id ='$id' AND status='available'";
        $sql1 = "SELECT * FROM register where rollno ='$rollno'";
        $result = $conn->query($sql);
        $result1 = $conn->query($sql1);
        if (($result->num_rows > 0) && ($result1->num_rows > 0)) {
            while ($row1 = $result1->fetch_assoc()) {
                $name = $row1['name'];
            }
            $stmt = $conn->prepare("INSERT INTO booking  VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssss", $id, $rollno, $name, $year, $semester, $date, $status);
            $date = date('Y-m-d');
            $status = "pending";
            if ($stmt->execute()) {
                $_SESSION['error'] = "Journal Is Reserved";
                header("location:JournalSearch.php");
            } else {
                $_SESSION['error'] = "please Try Again";
                header("location:JournalSearch.php");
            }
        } else {
            $_SESSION['error'] = "Enter Valid Data ";
            header("location:JournalSearch.php");
        }
    }
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-flask"></i> &nbsp;Reserve Journal &nbsp;&nbsp;<a href="JournalSearch.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="showback" style="color:#000">


                                        <link href="assets/css/bcss.css" rel="stylesheet">

                                        <form action=" JournalReserve.php" method="post">
                                            <center><h3 class="fa fa-2x"><i class="fa fa-cog"></i>&nbsp;&nbsp;&nbsp;Reserve Now</h3></center>
                                            <div>

                                                <div class="container">
                                                    <label><b>JournalID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                    <input type="text" placeholder="Enter JournalID" name="journalid" value="<?php
                                                    if (isset($_POST['BKID'])) {
                                                        echo $_POST['BKID'];
                                                    }
                                                    ?>" readonly><br><br>
                                                    <label><b>RollNumber&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                    <input type="text" name="rollno" value="<?php
                                                    if (isset($_SESSION['username'])) {
                                                        echo $_SESSION['username'];
                                                    }
                                                    ?>" readonly><br><br>

                                                    <label><b>Year &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                    <select name="year" required>
                                                        <option value="">Select</option>
                                                        <option value="First">First Year</option>
                                                        <option value="Second">Second Year</option>
                                                        <option value="Third" >Third Year</option>
                                                        <option value="Final" >Final Year</option>
                                                        <option value="NA" >NA - Faculty</option>
                                                    </select><br> <br>
                                                    <label><b>Semester&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                    <select name="sem" required>
                                                        <option  value="">Select</option>
                                                        <option  value="One" > One</option>
                                                        <option  value="Two">Two</option>
                                                        <option  value="Three" > Three</option>
                                                        <option  value="Four" > Four</option>
                                                        <option  value="Five"> Five</option>
                                                        <option  value="Six" > Six</option>
                                                        <option  value="Seven" > Seven</option>
                                                        <option  value="Eight" > Eight</option>
                                                        <option value="NA" >NA - Faculty</option>
                                                    </select><br><br>
                                                </div>
                                                <center><button class="btn btn-primary fa-1x" name="reserve"><i class="fa fa-edit"></i>&nbsp;&nbsp;Reserve</button>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <a href="JournalSearch.php"><button type="button"  class="btn btn-danger fa-1x"><i class="fa fa-trash-o"></i>&nbsp;&nbsp;Cancel</button></a>
                                                </center>
                                            </div></form>



                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div></div>
                            <?php include 'Links/Topers.php'; ?>
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end-->
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>