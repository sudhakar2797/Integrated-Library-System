<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        <?php
        echo "Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology";
        ?>
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->