<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
<!--sidebar start-->
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">

            <p class="centered"><a href="Profile.php"><img src="assets/img/logo.png" class="img-circle" width="60"></a></p>
            <h5 class="centered">
                <?php
                require 'dbconnect.php';
                $rollno = $_SESSION['username'];
                $query = "SELECT * FROM register WHERE rollno='$rollno'";
                $sql = $conn->query($query);
                if ($sql->num_rows > 0) {
                    while ($row = $sql->fetch_assoc()) {
                        $name1 = $row['role'];
                    }
                }
                echo $name1;
                ?>                  
            </h5>

            <li class="mt">
                <a class="active" href="Home.php">
                    <i class="fa fa-home"></i>
                    <span>Home</span>
                </a>
            </li>
            <?php if ($name1 == "admin") { ?>
                <li class="">
                    <a href="Panel.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Panel</span>
                    </a>
                </li><?php } ?>
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="fa fa-search"></i>
                    <span>Search</span><i class="fa fa-angle-down pull-right"></i>
                </a>
                <ul class="sub">
                    <li><a  href="BookSearch.php"><i class="fa fa-book"></i><span>Book</span></a></li>
                    <li><a  href="JournalSearch.php"><i class="fa fa-book"></i><span>Journal</span></a></li>
                    <li><a  href="ProjectSearch.php"><i class="fa fa-book"></i><span>Project Report</span></a></li>
                    <li><a  href="ManualSearch.php"><i class="fa fa-book"></i><span>Manuals</span></a></li>

                </ul>
            </li>
            <li class="">
                <a  href="RecentTrends.php">
                    <i class="fa fa-bolt"></i>
                    <span>Recent Trends</span>
                </a>
            </li>
            <li class="">
                <a  href="History.php">
                    <i class="fa fa-clock-o"></i>
                    <span>History</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="fa fa-gavel"></i>
                    <span>Rules</span><i class="fa fa-angle-down pull-right"></i>
                </a>
                <ul class="sub">
                    <li><a  href="StudentRule.php"><i class="fa fa-users"></i><span>Student</span></a></li>
                    <li><a  href="FacultyRule.php"><i class="fa fa-user"></i><span>Faculty</span></a></li>
                </ul>
            </li>
            <li class="">
                <a  href="Gallery.php">
                    <i class="fa fa-photo"></i>
                    <span>Gallery</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="fa fa-coffee"></i>
                    <span>About & Help</span><i class="fa fa-angle-down pull-right"></i>
                </a>
                <ul class="sub">
                    <li>
                        <a  href="Help.php">
                            <i class="fa fa-heart"></i>
                            <span>Help</span>
                        </a>
                    </li>
                    <li>
                        <a  href="About.php">
                            <i class="fa fa-laptop"></i>
                            <span>About</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<?php mysqli_close($conn); ?>