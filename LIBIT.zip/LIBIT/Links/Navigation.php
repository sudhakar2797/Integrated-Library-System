<!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
<!--header start-->
<header class="header black-bg">
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="#" class="logo"><b>LIB-IT</b></a>
    <!--logo end-->
    <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
            <!-- settings start -->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <i class="fa fa-tasks"></i>
                    <span class="badge bg-theme">

                        <i class="fa fa-clock-o"></i>

                    </span>
                </a>
                <?php require 'HoldingBooks.php'; ?>
            </li>
            <!-- settings end -->
            <!-- inbox dropdown start-->
            <li id="header_inbox_bar" class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-theme">

                        <i class="fa fa-gift"></i>

                    </span>
                </a>
                <?php require 'ReservedBooks.php'; ?>

            </li>
            <!-- inbox dropdown end -->
        </ul>
        <!--  notification end -->
    </div>
    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    } require 'dbconnect.php';
    if (isset($_SESSION['GateWay'])) {
        ?>
        <div class="top-menu">
            <ul class="nav pull-right top-menu">
                <li><a class="logout" href="Logout.php"><i class="fa fa-user"></i>&nbsp;&nbsp;LogOut</a></li>
            </ul>
        </div>
    <?php } else {
        ?>
        <div class="top-menu">
            <ul class="nav pull-right top-menu">
                <li><a class="logout" href="Index.php"><i class="fa fa-user"></i>&nbsp;&nbsp;LogIn</a></li>
            </ul>
        </div>  
        <?php
    }
    ?>



</header>
<!--header end-->