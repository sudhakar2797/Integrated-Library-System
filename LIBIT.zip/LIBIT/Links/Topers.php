<?php
require 'dbconnect.php';
$sql = "SELECT * FROM coordinators";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $dfirst = $row['firstyear'];
    $dsecond = $row['secondyear'];
    $dthird = $row['thirdyear'];
    $dfinal = $row['finalyear'];
}
?>    

<!-- **********************************************************************************************************************************************************
RIGHT SIDEBAR CONTENT
*********************************************************************************************************************************************************** -->                  

<div class="col-lg-3 col-md-12 col-sm-12 ds">
    <!--COMPLETED ACTIONS DONUTS CHART-->
    <h3>NOTIFICATIONS</h3>

    <!-- First Action -->
    <div class="desc">
        <div class="thumb">
            <span class="badge bg-theme"><i class="fa fa-clock-o"></i></span>
        </div>
        <div class="details">
            <?php
            require 'dbconnect.php';
            $query = "SELECT * FROM notification";
            $sql = $conn->query($query);
            if ($sql->num_rows > 0) {
                $row = $sql->fetch_assoc();
                $date = $row['date'];
                $msg = $row['message'];
            }
            ?>
            <p class="p"><muted><?php echo $date; ?></muted><br/>
            <?php echo $msg; ?><br/>
            </p>
        </div>
    </div>

    <!-- USERS ONLINE SECTION -->
    <h3>COORDINATORS</h3>
    <!-- First Member -->

    <div class="desc">
        <div class="thumb">
            <img class="img-circle" src="assets/img/4.jpg" width="35px" height="35px" align="">
        </div>
        <div class="details">
            <p class="p"> <?php
                if (isset($dfinal)) {
                    echo $dfinal;
                }
                ?><br/>
            <muted>Final Year</muted>
            </p>
        </div>
    </div>
    <div class="desc">
        <div class="thumb">
            <img class="img-circle" src="assets/img/3.png" width="35px" height="35px" align="">
        </div>
        <div class="details">
            <p class="p"><?php
                if (isset($dthird)) {
                    echo $dthird;
                }
                ?><br/>
            <muted>Third Year</muted>
            </p>
        </div>
    </div>
    <div class="desc">
        <div class="thumb">
            <img class="img-circle" src="assets/img/2.jpg" width="35px" height="35px" align="">
        </div>
        <div class="details">
            <p class="p"><?php
                if (isset($dsecond)) {
                    echo $dsecond;
                }
                ?><br/>
            <muted>Second Year</muted>
            </p>
        </div>
    </div>
    <div class="desc">
        <div class="thumb">
            <img class="img-circle" src="assets/img/1.jpg" width="35px" height="35px" align="">
        </div>
        <div class="details">
            <p class="p"><?php
                if (isset($dfirst)) {
                    echo $dfirst;
                }
                ?><br/>
            <muted>First Year</muted>
            </p>
        </div>
    </div>

</div><!-- /col-lg-3 -->