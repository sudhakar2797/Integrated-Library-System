<style>/* The Modal (background) */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        padding-top: 100px; /* Location of the box */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

    /* Modal Content */
    .modal-content {
        position: relative;
        background-color: #fefefe;
        margin: auto;
        padding: 0;
        border: 1px solid #888;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
        -webkit-animation-name: animatetop;
        -webkit-animation-duration: 0.4s;
        animation-name: animatetop;
        animation-duration: 0.4s;
                    width: 50%; /* Full width */

    }

    /* Add Animation */
    @-webkit-keyframes animatetop {
        from {top:-300px; opacity:0} 
        to {top:0; opacity:1}
    }

    @keyframes animatetop {
        from {top:-300px; opacity:0}
        to {top:0; opacity:1}
    }

    /* The Close Button */
    .close {
        color: white;
        float: right;
        font-size: 28px;
        font-weight: bold;
        color: #ffffff;
    }

    .close:hover,
    .close:focus {
        color: #ffffff;
        text-decoration: none;
        cursor: pointer;
    }

    .modal-header {
        padding: 2px 16px;
        background-color: #222211;
        color: white;
        text-transform: capitalize;
    }

    .modal-body {padding: 2px 16px;}

    .modal-footer {
        padding: 2px 16px;
        background-color: #222211;
        color: white;
    }</style>

<!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
<!--sidebar start-->
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <p class="centered"><a href="Welcome.php"><img src="assets/img/logo.png" class="img-circle" width="60"></a></p>
            <h5 class="centered">
                LIB-IT User            
            </h5>
            <li  class="mt">
                <a class="active" href="Index.php">
                    <i class="fa fa-user"></i>
                    <span>Login</span>
                </a>
            </li>	
            <li>
                <a  href="Welcome.php">
                    <i class="fa fa-home"></i>
                    <span>Home</span>
                </a>
            </li>
            <li  id="myBtn">
                <a href="#">
                    <i class="fa fa-search"></i>
                    <span>Search</span><i class="fa fa-angle-down pull-right"></i>
                </a>
            </li>
            <li id="myBtn0">
                <a  href="#">
                    <i class="fa fa-clock-o"></i>
                    <span>History</span>
                </a>
            </li>
            <li id="myBtn4">
                <a  href="#">
                    <i class="fa fa-bolt"></i>
                    <span>Recent Trends</span>
                </a>
            </li>
            <li id="myBtn1" >
                <a href="#" >
                    <i class="fa fa-gavel"></i>
                    <span>Rules</span><i class="fa fa-angle-down pull-right"></i>
                </a>
            </li>
            <li id="myBtn2">
                <a  href="#">
                    <i class="fa fa-photo"></i>
                    <span>Gallery</span>
                </a>
            </li>
            <li id="myBtn3">
                <a  href="#">
                    <i class="fa fa-coffee"></i>
                    <span>About & Help</span><i class="fa fa-angle-down pull-right"></i>
                </a>
            </li>
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<div id="myModal" class="modal">
    <div class="row">
        <div class="col-lg-10 col-md-12 col-sm-12 main-chart">		
            <div class="col-lg-10 col-md-12 col-sm-12">
                <div class="modal-content">
                    <div class="modal-header" >
                        <span class="close">×</span>
                        <center><h3 style="color:white;font-size: 30px;font-family: calibri;text-transform:none">Department Library</h3></center>
                    </div>
                    <div class="modal-body" align="center"><br>
                        <img class="img-responsive" src="assets/img/welcome.jpg"width=200px" height="200px">
                        <h5 style="color:black;font-family: calibri;font-size: 25px;style:bold;"> Please <b style="display:inline; color:crimson;">Login</b> First.....
                            <a href="Index.php"><button class="btn btn-primary fa-1x"><i class="fa fa-users"></i>&nbsp;<span>Click Here</span></button></a></h5>
                    </div>
                    <div class="modal-footer" alifn="center">
                        <center><h3 style="color:white;font-size: 25px;font-family: calibri;text-transform:none"><i class="fa fa-coffee"></i> &nbsp;&nbsp;&nbsp;Welcome To All&nbsp;&nbsp;&nbsp;<i class="fa fa-gift"></i></h3></center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// Get the modal
    var modal = document.getElementById('myModal');

// Get the button that opens the modal
    var btn = document.getElementById("myBtn");
    var btn1 = document.getElementById("myBtn1");
    var btn2 = document.getElementById("myBtn2");
    var btn3 = document.getElementById("myBtn3");
    var btn4 = document.getElementById("myBtn4");

    var btn0 = document.getElementById("myBtn0");

// Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
    btn.onclick = function () {
        modal.style.display = "block";
    }

// When the user clicks the button, open the modal 
    btn1.onclick = function () {
        modal.style.display = "block";
    }

// When the user clicks the button, open the modal 
    btn2.onclick = function () {
        modal.style.display = "block";
    }

// When the user clicks the button, open the modal 
    btn3.onclick = function () {
        modal.style.display = "block";
    }

// When the user clicks the button, open the modal 
    btn4.onclick = function () {
        modal.style.display = "block";
    }
// When the user clicks the button, open the modal 
    btn0.onclick = function () {
        modal.style.display = "block";
    }

// When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

// When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
