<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-laptop"></i> &nbsp;Mail Alert&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <?php if (!empty($_SESSION['merror'])) { ?>
                                    <link href="assets/css/alert.css" rel="stylesheet" />
                                    <h4 class="alert alert-success">
                                        <?php echo $_SESSION['merror']; ?>
                                        <span class="closebtn">&times;</span>  
                                        <script>
                                            var close = document.getElementsByClassName("closebtn");
                                            var i;

                                            for (i = 0; i < close.length; i++) {
                                                close[i].onclick = function () {
                                                    var div = this.parentElement;
                                                    div.style.opacity = "0";
                                                    setTimeout(function () {
                                                        div.style.display = "none";
                                                    }, 600);
                                                }
                                            }
                                        </script></h4><?php } ?>

                                <div class="col-lg-9 main-chart">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="showback">
                                            <link rel="stylesheet" type="text/css" href="assets/css/mail.css" />
                                            <link rel="stylesheet" type="text/css" href="assets/css/today.css">
                                            <center><div class="wrap">
                                                    <div class="pricing-grid1">
                                                        <div class="price-value" >
                                                            <h2 style="font-family: calibri;"> Mail Alert</h2>
                                                            <div class="sale-box">
                                                                <span class="on_sale title_shop">Today</span>
                                                            </div>
                                                        </div>
                                                        <div class="cart1" >
                                                            <form method="post" action="MailAlert.php">
                                                                <button name="mail" >Show Me</button></form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </center>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <?php
                                        if (isset($_POST['mail'])) {
                                            echo '<div class="showback" style="color: #000;"> ';
                                            echo'<table>';
                                            echo'<thead>';
                                            echo'<tr>';
                                            echo'<th>Name</th>';
                                            echo'<th>Mail ID</th>';
                                            echo'</tr>';
                                            echo'</thead>';
                                            echo'<tbody>';
                                            require 'dbconnect.php';
                                            $date = date('Y-m-d');
                                            $query = "SELECT * FROM transaction WHERE status='granted' AND returndate <='$date' ";
                                            $sql = $conn->query($query);
                                            if ($sql->num_rows > 0) {
                                                while ($row = $sql->fetch_assoc()) {
                                                    $rollno = $row['id'];
                                                    $query1 = "SELECT * FROM register WHERE rollno='$rollno' ";
                                                    $sql1 = $conn->query($query1);
                                                    if ($sql1->num_rows > 0) {
                                                        while ($row1 = $sql1->fetch_assoc()) {
                                                            echo'<tr><td style="color:maroon"; class="user-name">' . $row1['name'] . '</td><td style="color:indigo;" class="user-name">' . $row1['emailid'] . '</td></tr>';
                                                        }
                                                    }
                                                }
                                                echo'<div class="cart1" ><form action="Send.php" method="post"><button name="send">Send</button></form></div>';
                                            } else {
                                                echo'<tr ><td colspan="2" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                                            }
                                        }
                                        echo'</tbody>';
                                        echo'</table>';
                                        echo '</div>';
                                        ?><?php
                                        if (!empty($_SESSION['merror'])) {
                                            unset($_SESSION['merror']);
                                        }
                                        ?>   
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            </div><! --/row -->
                        </section>
                    </section><br><br><br><br><br><br><br><br><br><br><br>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
