<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Add Manual &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a>
                                    &nbsp;&nbsp;<span style="color:purple; font-size: 20px;">
                                        <i class="fa fa-bell"></i>&nbsp;Last Inserted Manual's ID :
                                        <?php
                                        require 'dbconnect.php';
                                        $query = "SELECT id FROM manual ORDER BY id DESC";
                                        $sql = $conn->query($query);
                                        if ($sql->num_rows > 0) {
                                            $row = $sql->fetch_assoc();
                                            echo $row['id'];
                                        }
                                        ?>&nbsp;<i class="fa fa-bell"></i>
                                    </span>
                                </h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback">
                                            <?php if (!empty($_SESSION['msg'])) { ?>
                                                <link href="assets/css/alert.css" rel="stylesheet" />
                                                <h4 class="alert alert-success">
                                                    <?php echo $_SESSION['msg']; ?>
                                                    <span class="closebtn">&times;</span>  
                                                    <script>
                                                        var close = document.getElementsByClassName("closebtn");
                                                        var i;

                                                        for (i = 0; i < close.length; i++) {
                                                            close[i].onclick = function () {
                                                                var div = this.parentElement;
                                                                div.style.opacity = "0";
                                                                setTimeout(function () {
                                                                    div.style.display = "none";
                                                                }, 600);
                                                            }
                                                        }
                                                    </script></h4><?php } ?>
                                            <link rel="stylesheet" type="text/css"  media="all" href="assets/css/styles.css">
                                            <div style="background-color: #357ae8;"><br>
                                                <div class="p3">  
                                                    <div id="wrapper">  
                                                        <h3 style="color:white; font-family:calibri; text-align: center;font-size: 30px">Lab Manual Adding From</h3>
                                                        <form name="form1" method="post" action="CheckManual.php" >
                                                            <div class="col-1">
                                                                <label>Manual Title
                                                                    <input placeholder="Title Of The Manual"  name="mname" required>
                                                                </label>
                                                            </div>
                                                            <div class="col-2">
                                                                <label>Manual ID
                                                                    <input placeholder=" ID Of The Manual" name="iom" required>
                                                                </label>
                                                            </div>
                                                            <div class="col-2">
                                                                <label>Lab Name
                                                                    <input placeholder="Name Of The Lab"  name="nol" required>
                                                                </label>
                                                            </div>
                                                            <div class="col-submit">
                                                                <button class="submitbtn" name="add" >Add To Library</button>
                                                            </div>
                                                        </form>  
                                                        <?php
                                                        if (!empty($_SESSION['msg'])) {
                                                            unset($_SESSION['msg']);
                                                        }
                                                        ?>
                                                    </div>
                                                </div><br>
                                            </div>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
