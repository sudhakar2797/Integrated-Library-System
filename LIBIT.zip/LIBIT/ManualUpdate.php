<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><?php
        $titleerror = $error = $labnameerror = $statuserror = $dateofadderror = "";
        $acc = 0;
        if (isset($_POST['update'])) {
            $acc = 1;
            $error = " Nothing Updated";
            require 'dbconnect.php';
            if (!empty($_POST['manualid'])) {

                $manualid = $_POST['manualid'];
                $query = "SELECT * FROM manual WHERE id='$manualid'";
                $sql = $conn->query($query);
                if ($sql->num_rows > 0) {
                    if (!empty($_POST['nmanualid'])) {
                        $title = $_POST['nmanualid'];
                        $sql = "UPDATE manual SET id='$title' WHERE id='$manualid'";
                        if ($conn->query($sql)) {
                            $titleerror = "Manual ID Successfully Updated";
                        } else {
                            $titleerror = "Manual ID Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newtitle'])) {
                        $title = $_POST['newtitle'];
                        $sql = "UPDATE manual SET title='$title' WHERE id='$manualid'";
                        if ($conn->query($sql)) {
                            $titleerror .= "   Title Successfully Updated";
                        } else {
                            $titleerror .= "   Title Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newlabname'])) {
                        $labname = $_POST['newlabname'];
                        $sql = "UPDATE manual SET labname='$labname' WHERE id='$manualid'";
                        if ($conn->query($sql)) {
                            $labnameerror = "Labname Successfully Updated";
                        } else {
                            $titleerror = " Labname Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newdateofadd'])) {
                        $dateofadd = $_POST['newdateofadd'];
                        $old = strtotime($dateofadd);
                        $dateofadd = date('Y-m-d ', $old);
                        $sql = "UPDATE manual SET dateofadd='$dateofadd' WHERE id='$manualid'";
                        if ($conn->query($sql)) {
                            $dateofadderror = "Date Of Add Successfully Updated";
                        } else {
                            $dateofadderror = " Date Of Add Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newstatus'])) {
                        $status = $_POST['newstatus'];
                        $sql = "UPDATE manual SET status='$status' WHERE id='$manualid'";
                        if ($conn->query($sql)) {
                            $statuserror = "Status Successfully Updated";
                        } else {
                            $statuserror = " Status Not Updated Please Try Again";
                        }
                    }
                } else {
                    $error = "Please Enter Valid ManualId";
                }
            } else {
                $error = "Please Enter ManualId";
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Manual&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000;">
                                            <style>             
                                                input[type=text]:focus {
                                                    width: 55%;
                                                }
                                                input[type=text]:hover {
                                                    width: 55%;
                                                }
                                            </style>
                                            <center> 
                                                <form method="post" action="ManualUpdate.php">
                                                    <link rel="stylesheet" href="assets/css/update.css">
                                                    <?php if ($acc == 1) { ?>  <link href="assets/css/alert.css" rel="stylesheet">
                                                        <div class="alert alert-danger">
                                                            <span class="closebtn">&times;</span>  
                                                            <?php
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $error . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $titleerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $labnameerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $dateofadderror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $statuserror . '</h3>';
                                                            ?>
                                                        </div>
                                                        <script>
                                                            var close = document.getElementsByClassName("closebtn");
                                                            var i;

                                                            for (i = 0; i < close.length; i++) {
                                                                close[i].onclick = function () {
                                                                    var div = this.parentElement;
                                                                    div.style.opacity = "0";
                                                                    setTimeout(function () {
                                                                        div.style.display = "none";
                                                                    }, 600);
                                                                }
                                                            }
                                                        </script><?php } ?> 
                                                    <div  align="center">
                                                        <ul class="tab">
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Id')" id="defaultOpen">Id</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Title')">Title</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Labname')">Labname</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'DateOfAdd')">DateOfAdd</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Status')">Status</a></li>
                                                        </ul>
                                                        <div id="Id" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <h3 style="font-size:25px;color:maroon;font-family:calibri;">Manual Update</h3>
                                                            <br><spen style="color:#6600ff;font-size: #12px"> * Manual ID</spen>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <input type="text" name="manualid" placeholder="Enter The ManualId, You Want To Update" required/><br>
                                                            <br><spen style="color:#6600ff;font-size: #12px"> New Manual ID</spen>
                                                            <input type="text" name="nmanualid" placeholder="Enter The ManualId" required/><br>
                                                            <br><button name="update" class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;update</button>
                                                            <h4 style="font-family: calibri;font-size: 20px;color:indigo; ">** If You Don't Known About The ManualId Please Use " Display Option " To Find The ManualId **</h4>

                                                        </div>
                                                        <div id="Title" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Manual Title</h3><br>
                                                            <input type="text" name="newtitle" placeholder="        Enter The  New Manual Title   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Labname" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change labname Of The Manual</h3><br>
                                                            <input type="text" name="newlabname" placeholder="       Enter The New labname   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br></div>
                                                        <div id="DateOfAdd" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Date Of Add</h3><br>
                                                            <input type="text" name="newdateofadd"  id="datepicker1" placeholder="        Enter The New Date Of Add   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br></div>
                                                        <div id="Status" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Manual Status</h3><br>
                                                            <input type="text" name="newstatus" placeholder="Enter Status available / notavailable   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                    </div>
                                                </form>
                                            </center>
                                            <script>
                                                function openCity(evt, cityName) {
                                                    var i, tabcontent, tablinks;
                                                    tabcontent = document.getElementsByClassName("tabcontent");
                                                    for (i = 0; i < tabcontent.length; i++) {
                                                        tabcontent[i].style.display = "none";
                                                    }
                                                    tablinks = document.getElementsByClassName("tablinks");
                                                    for (i = 0; i < tablinks.length; i++) {
                                                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                                                    }
                                                    document.getElementById(cityName).style.display = "block";
                                                    evt.currentTarget.className += " active";
                                                }
                                                // Get the element with id="defaultOpen" and click on it
                                                document.getElementById("defaultOpen").click();
                                            </script>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <link rel="stylesheet" href="jq/jquery-ui.css">
                <script src="jq/jquery.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
                <script src="jq/jquery-ui.js"></script>
                <script>
                                                $(function () {
                                                    $("#datepicker").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                                                $(function () {
                                                    $("#datepicker1").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker1").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                </script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
