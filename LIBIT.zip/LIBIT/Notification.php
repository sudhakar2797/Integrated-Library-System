<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <?php
        require 'dbconnect.php';
        $msg = "";
        if (isset($_POST['send'])) {
            $message = $_POST['msg'];
            $date = date('Y-m-d');
            $sql = "UPDATE `notification` SET `date`='$date',`message`='$message' WHERE 1";
            if ($conn->query($sql)) {
                $msg = " Successfully sent";
            } else {
                $msg = " Please Try Again";
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">   <link rel="stylesheet" type="text/css" href="assets/css/icss.css">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-gift"></i> &nbsp;Notification &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <?php if (!empty($msg)) { ?>
                                            <h4 class="alert alert-success">
                                                <?php echo $msg; ?>
                                                <span class="closebtn">&times;</span>  
                                                <script>
                                                    var close = document.getElementsByClassName("closebtn");
                                                    var i;

                                                    for (i = 0; i < close.length; i++) {
                                                        close[i].onclick = function () {
                                                            var div = this.parentElement;
                                                            div.style.opacity = "0";
                                                            setTimeout(function () {
                                                                div.style.display = "none";
                                                            }, 600);
                                                        }
                                                    }
                                                </script></h4><?php } ?>
                                        <div class="showback" style="color: #000;">
                                            <h3><i class="fa fa-envelope"></i>&nbsp;&nbsp;&nbsp;Add Message</h3><br>
                                            <form  action="Notification.php" method="post">
                                                <input type="text" name="msg" placeholder="Enter Your Message/Notification Here " required></input>
                                                <input type="submit" name="send" class="login login-submit" value="Send">
                                            </form>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
