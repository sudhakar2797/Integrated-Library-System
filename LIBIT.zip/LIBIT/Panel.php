<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-dashboard"></i> &nbsp;Admin panel</h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback">
                                            <style>
                                                button::-moz-focus-inner {
                                                    border: 0;
                                                }
                                                input[type=submit]::-moz-focus-inner {
                                                    border: 0;
                                                }

                                                button.accordion {
                                                    background-color: #eee;
                                                    color: #444;
                                                    cursor: pointer;
                                                    padding: 8px;
                                                    width: 65%;
                                                    border: none;
                                                    text-align: center;
                                                    outline: none;
                                                    font-size: 15px;
                                                    transition: 0.4s;
                                                }
                                                button.accordion.active, button.accordion:hover {
                                                    background-color: #ddd;
                                                }
                                                button.accordion:after {
                                                    content: '\02795';
                                                    font-size: 13px;
                                                    color: #777;
                                                    float: right;
                                                    margin-left: 5px;
                                                }
                                                button.accordion.active:after {
                                                    content: "\2796";
                                                }
                                                div.panel {
                                                    padding: 0 18px;
                                                    background-color: white;
                                                    max-height: 0;
                                                    overflow: hidden;
                                                    transition: 0.6s ease-in-out;
                                                    opacity: 0;
                                                }
                                                div.panel.show {
                                                    opacity: 1;
                                                    max-height: 500px;  
                                                }
                                                h4{
                                                    color: crimson;
                                                    font-family: calibri;
                                                    font-size: 30px;
                                                    text-align: center;
                                                }
                                            </style>
                                            <center>  
                                                <image src="assets/img/image/admin.ico" width="75px" height="75px"/><br><br>
                                                <button class="accordion">Transaction</button>
                                                <div class="panel">
                                                    <h4>Library</h4>
                                                    <a href="DailyStatus.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Daily Status</button></a>
                                                    <a href="BookReturn.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Book Return</button></a><br><br>
                                                    <a href="MailAlert.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Mail Alert</button></a>
                                                    <a href="Notification.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Add Notification</button></a><br><br>
                                                    <a href="Coordinators.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Change Coordinators</button></a>
                                                    <a href="PhotoToGallery.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Add/Delete Photo</button></a>
                                                    <a href="PhotoToTrends.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update Trends</button></a>
                                                </div>
                                                <button class="accordion">Report</button>
                                                <div class="panel">
                                                    <h4>Library Report</h4>
                                                    <a href="TransactionReport.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Monthly Transaction </button></a>
                                                    <a href="BookAvailableReport.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Book Availability</button></a><br><br>
                                                    <a href="ProjectAvailableReport.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Project Availability</button></a>
                                                    <a href="ManualAvailableReport.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Manual Availability</button></a><br><br>
                                                    <a href="JournalAvailableReport.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Journal Availability</button></a>
                                                    <a href="BookNotReturn.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Not Return Report</button></a>
                                                </div>
                                                <button class="accordion">User</button>
                                                <div class="panel">
                                                    <h4>User</h4>
                                                    <a href="BulkUser.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Bulk Insert</button></a>
                                                    <a href="Register.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Single Insert</button></a><br><br>
                                                    <a href="UserDelete.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Delete</button></a>
                                                    <a href="UserUpdate.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></a><br><br>
                                                    <a href="UserDisplay.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Display</button></a>
                                                </div>
                                                <button class="accordion">Book</button>
                                                <div class="panel">
                                                    <h4>Book</h4>
                                                    <a href="BulkBook.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Bulk Insert</button></a>
                                                    <a href="Book.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Single Insert</button></a><br><br>
                                                    <a href="BookDelete.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Delete</button></a>
                                                    <a href="BookUpdate.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></a><br><br>
                                                    <a href="BookDisplay.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Display</button></a>
                                                </div>
                                                <button class="accordion">Project</button>
                                                <div id="foo" class="panel">
                                                    <h4>Project</h4>
                                                    <a href="BulkProject.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Bulk Insert</button></a>
                                                    <a href="Project.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Single Insert</button></a><br><br>
                                                    <a href="ProjectDelete.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Delete</button></a>
                                                    <a href="ProjectUpdate.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></a><br><br>
                                                    <a href="ProjectDisplay.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Display</button></a>
                                                </div>         
                                                <button class="accordion">Manual</button>
                                                <div id="foo" class="panel">
                                                    <h4>Manual</h4>
                                                    <a href="BulkManual.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Bulk Insert</button></a>
                                                    <a href="Manual.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Single Insert</button></a><br><br>
                                                    <a href="ManualDelete.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Delete</button></a>
                                                    <a href="ManualUpdate.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></a><br><br>
                                                    <a href="ManualDisplay.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Display</button></a>
                                                </div>                 
                                                <button class="accordion">Journal</button>
                                                <div id="foo" class="panel">
                                                    <h4>Journal</h4>
                                                    <a href="BulkJournal.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Bulk Insert</button></a>
                                                    <a href="Journal.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Single Insert</button></a><br><br>
                                                    <a href="JournalDelete.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Delete</button></a>
                                                    <a href="JournalUpdate.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></a><br><br>
                                                    <a href="JournalDisplay.php"><button class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;&nbsp;Display</button></a>
                                                </div>
                                                <script>
                                                    var acc = document.getElementsByClassName("accordion");
                                                    var i;
                                                    for (i = 0; i < acc.length; i++) {
                                                        acc[i].onclick = function () {
                                                            this.classList.toggle("active");
                                                            this.nextElementSibling.classList.toggle("show");
                                                        }
                                                    }
                                                </script> 
                                            </center>
                                        </div>
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>


