<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?><?php
$msg = "";
if (isset($_POST['delete'])) {
    if (!empty($_POST['imgid'])) {
        $imageid = $_POST['imgid'];
        require 'dbconnect.php';

        $query = "DELETE  FROM trends WHERE image_id='$imageid'";
        if ($conn->query($query)) {
            $msg = " image Successfully Deleted";
        } else {
            $msg = " Please Try Again";
        }
    } else {
        $msg = " Enter Valid Trend ID...";
    }
}
?>  


<?php
if (isset($_POST['add'])) {
    /*     * * check if a file was submitted ** */
    error_reporting(E_ERROR | E_PARSE);

    if (!isset($_FILES['userfile'])) {
        $msg = "Please select a file";
    } else {
        try {
            upload();
            /*             * * give praise and thanks to the php gods ** */
            $msg = "Successfully Inserted";
        } catch (PDOException $e) {
            $msg = $e->getMessage();
        } catch (Exception $e) {
            $msg = $e->getMessage();
        }
    }
}

/**
 *
 * the upload function
 * 
 * @access public
 *
 * @return void
 *
 */
function upload() {
    /*     * * check if a file was uploaded ** */
    if (is_uploaded_file($_FILES['userfile']['tmp_name']) && getimagesize($_FILES['userfile']['tmp_name']) != false) {
        /*         * *  get the image info. ** */
        $size = getimagesize($_FILES['userfile']['tmp_name']);

        /*         * * assign our variables ** */
        $image_type = $size['mime'];
        $imgfp = fopen($_FILES['userfile']['tmp_name'], 'rb');
        $image_width = $size[0];
        $image_height = $size[1];
        $image_size = $size[3];
        $image_name = $_FILES['userfile']['name'];
        $maxsize = 99999999;

        /*         * *  check the file is less than the maximum file size ** */
        if ($_FILES['userfile']['size'] < $maxsize) {
            /*             * * create a second variable for the thumbnail ** */
            $thumb_data = $_FILES['userfile']['tmp_name'];

            /*             * * get the aspect ratio (height / width) ** */
            $aspectRatio = (float) ($size[0] / $size[1]);

            /*             * * the height of the thumbnail ** */
            $thumb_height = 100;

            /*             * * the thumb width is the thumb height/aspectratio ** */
            $thumb_width = $thumb_height * $aspectRatio;

            /*             * *  get the image source ** */
            $src = ImageCreateFromjpeg($thumb_data);

            /*             * * create the destination image ** */
            $destImage = ImageCreateTrueColor($thumb_width, $thumb_height);

            /*             * * copy and resize the src image to the dest image ** */
            ImageCopyResampled($destImage, $src, 0, 0, 0, 0, $thumb_width, $thumb_height, $size[0], $size[1]);

            /*             * * start output buffering ** */
            ob_start();

            /*             * *  export the image ** */
            imageJPEG($destImage);

            /*             * * stick the image content in a variable ** */
            $image_thumb = ob_get_contents();

            /*             * * clean up a little ** */
            ob_end_clean();

            /*             * * connect to db ** */
            require 'Config.php';
            /*             * * set the error mode ** */
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            /*             * * prepare the sql ** */
            $stmt = $dbh->prepare("INSERT INTO trends (image)VALUES (?)");
            $stmt->bindParam(1, $imgfp, PDO::PARAM_LOB);

            /*             * * execute the query ** */
            $stmt->execute();
        } else {
            /*             * * throw an exception is image is not of type ** */
            throw new Exception("File Size Error");
        }
    } else {
        // if the file is not less than the maximum allowed, print an error
        throw new Exception("Unsupported Image Format!");
    }
}
?>
<?php
if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <style>
                #yourBtn{
                    font-family: calibri;
                    width: 160px;
                    -webkit-border-radius: 5px;
                    -moz-border-radius: 5px;
                    text-align: center;
                    background-color: #357ae8;
                    color: white;
                    padding: 14px 20px;
                    margin: 8px 0;
                    border: none;
                    cursor: pointer;
                }


                #yourBtn:hover{

                    background-color: #0000FF;

                }
                button::-moz-focus-inner {
                    border: 0;
                }
                input[type=submit]::-moz-focus-inner {
                    border: 0;
                }
                input[type=file]::-moz-focus-inner {
                    border: 0;
                }


            </style>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-photo"></i> &nbsp;Update Trends&nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">
                                    <?php if (!empty($msg)) { ?>
                                        <div class="alert alert-info" >
                                            <span class="closebtn">&times;</span>  
                                            <?php echo $msg; ?>
                                        </div><?php } ?>
                                    <script>
                                        var close = document.getElementsByClassName("closebtn");
                                        var i;

                                        for (i = 0; i < close.length; i++) {
                                            close[i].onclick = function () {
                                                var div = this.parentElement;
                                                div.style.opacity = "0";
                                                setTimeout(function () {
                                                    div.style.display = "none";
                                                }, 600);
                                            }
                                        }
                                    </script>		
                                    <div class="col-lg-6 col-md-12 col-sm-12">

                                        <div class="showback" style="color:#000">
                                            <link href="assets/css/bcss.css" rel="stylesheet">
                                            <form action="PhotoToTrends.php" method="post" enctype="multipart/form-data">
                                                <center>
                                                    <h3 class="fa fa-2x">
                                                        <i class="fa fa-photo"></i>&nbsp;&nbsp;&nbsp;Add Trend
                                                    </h3>
                                                    <div id="yourBtn" onclick="getFile()">Click To Insert A Data</div>
                                                    <div style='height: 0px;width: 0px; overflow:hidden;'>
                                                        <input id="upfile" type="file" name="userfile"  size="40" onchange="sub(this)" required>
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10000000">
                                                    </div>
                                                </center><br>
                                                <script type="text/javascript">
                                                    function getFile() {
                                                        document.getElementById("upfile").click();
                                                    }
                                                    function sub(obj) {
                                                        var file = obj.value;
                                                        var fileName = file.split("\\");
                                                        document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
                                                        document.myForm.submit();
                                                        event.preventDefault();
                                                    }
                                                </script>              
                                                <center><button class="btn btn-primary fa-1x" name="add"><i class="fa fa-plus-square"></i>&nbsp;&nbsp;Add</button>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <a href="Panel.php"><button type="button"  class="btn btn-danger fa-1x"><i class="fa fa-trash-o"></i>&nbsp;&nbsp;Cancel</button></a>
                                                </center>
                                            </form>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000">
                                            <link href="assets/css/bcss.css" rel="stylesheet">
                                            <form action="PhotoToTrends.php" method="post" enctype="multipart/form-data">
                                                <center>
                                                    <h3 class="fa fa-2x">
                                                        <i class="fa fa-photo"></i>&nbsp;&nbsp;&nbsp;Delete Trend
                                                    </h3><br>
                                                    <label><b>Trend ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></label>
                                                    <input type="text" name="imgid" placeholder="Enter Trend Id To Delete"/><br>
                                                    <br><br><button class="btn btn-primary fa-1x" name="delete"><i class="fa fa-minus-square"></i>&nbsp;&nbsp;Delete</button>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <a href="Panel.php"><button type="button"  class="btn btn-danger fa-1x"><i class="fa fa-trash-o"></i>&nbsp;&nbsp;Cancel</button></a>
                                                </center>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000">
                                            <center> 
                                                <h5>Recent Trends Template view for Trend ID</h5>
                                            </center>
                                            <?php
                                            require 'dbconnect.php';
                                            $sql = "SELECT * FROM trends ";
                                            $sth = $conn->query($sql);
                                            $s = 0;
                                            while ($result = mysqli_fetch_array($sth)) {
                                                $s++;
                                                echo $result['image_id'] . '&nbsp;&nbsp;<i style="color:green" class="fa fa-photo fa-3x"></i>&nbsp;&nbsp;';
                                                if ($s == 4) {
                                                    echo'<br><br>';
                                                    $s = 0;
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div><?php include 'Links/Topers.php'; ?>

                            </div>       

                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>














