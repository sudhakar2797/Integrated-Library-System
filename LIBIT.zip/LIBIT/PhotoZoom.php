<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper site-min-height">
                        <h3><i class="fa fa-photo"></i>&nbsp;Photo Zoom  &nbsp;&nbsp;<a href="Gallery.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                        <hr>
                        <div class="row mt" style="border: 25px solid #fff;">


                            <?php
                            if (isset($_POST['zoom'])) {
                                $id = $_POST['imageid'];
                                require 'dbconnect.php';
                                $sql = "SELECT * FROM gallery WHere image_id='$id'";
                                $sth = $conn->query($sql);
                                $result = mysqli_fetch_array($sth);
                                echo '<img class="img-responsive" src="data:image/jpeg;base64,' . base64_encode($result['image']) . '"/>';
                            }
                            ?>   



                        </div><!-- /row -->
                    </section><! --/wrapper -->
                </section>
                <!--main content end-->
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>