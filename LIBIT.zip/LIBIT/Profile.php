<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?>
    <?php
    require 'dbconnect.php';
    $name = $rollno = $emailid = $role = $books = '';
    $rollno = $_SESSION['username'];
    $query = "SELECT `name`, `rollno`, `role`, `emailid`, `dateofadd` FROM `register` WHERE `rollno`='$rollno'";
    $query1 = "SELECT `bookname` FROM `transaction` WHERE `id`='$rollno' and status ='granted'";
    $sql = $conn->query($query);
    $sql1 = $conn->query($query1);
    if ($sql->num_rows > 0) {
        while ($row1 = $sql1->fetch_assoc()) {
            $books .= "  " . $row1['bookname'];
        }
        $row = $sql->fetch_assoc();
        $name = $row['name'];
        $rollno = $row['rollno'];
        $role = $row['role'];
        $emailid = $row['emailid'];
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <link href="assets/lineicons/style.css" rel="stylesheet">
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-user"></i> &nbsp;Profile&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="showback">
                                        <div class="content-panel">
                                            <table class="table table-striped table-advance table-hover">
                                                <center> 
                                                    <h4><i class="fa fa-user"></i>&nbsp;About You</h4>
                                                </center><hr>
                                                <thead>
                                                    <tr>
                                                        <th width="22%"><h6><i class="fa fa-bolt"></i>&nbsp;Category<h6></th>
                                                        <th><h6><i class="fa fa-bar-chart-o"></i>&nbsp;Data</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp; Name</h6></td>
                                                        <td><h6><i class="fa fa-exchange"></i>&nbsp;&nbsp;<?php echo $name; ?> </h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp; Roll No</h6></td>
                                                        <td><h6><i class="fa fa-exchange"></i>&nbsp;&nbsp;<?php echo $rollno; ?> </h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Role</h6></td>
                                                        <td><h6><i class="fa fa-exchange"></i>&nbsp; <?php echo $role; ?> </h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;EmailID</h6></td>
                                                        <td><h6><i class="fa fa-exchange"></i>&nbsp;&nbsp;<?php echo $emailid; ?></h6></td>
                                                    </tr>
                                                    <tr>
                                                        <td><h6><i class="fa fa-cogs"></i>&nbsp;&nbsp;Books</h6></td>
                                                        <td><h6><i class="fa fa-exchange"></i>&nbsp;&nbsp;<?php echo $books; ?> </h6></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div><!-- /content-panel -->
                                    </div>
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            </div>
                            <?php include 'Links/Topers.php'; ?>
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end-->
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
<?php
} else {
    header("location:Index.php");
}?>