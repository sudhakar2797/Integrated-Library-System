<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <?php if (!empty($_SESSION['error'])) { ?>
                            <h4 class="alert alert-success">
                                <?php echo $_SESSION['error']; ?>
                                <span class="closebtn">&times;</span>  
                                <script>
                                    var close = document.getElementsByClassName("closebtn");
                                    var i;

                                    for (i = 0; i < close.length; i++) {
                                        close[i].onclick = function () {
                                            var div = this.parentElement;
                                            div.style.opacity = "0";
                                            setTimeout(function () {
                                                div.style.display = "none";
                                            }, 600);
                                        }
                                    }
                                </script></h4><?php } ?><?php
                        if (!empty($_SESSION['error'])) {
                            unset($_SESSION['error']);
                        }
                        ?>
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Project&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="showback" style="color:#000;">
                                        <center> <link rel="stylesheet" type="text/css" href="assets/css/scss.css"><link rel="stylesheet" type="text/css" href="assets/css/component.css" />
                                            <h3>Search Project</h3><br>
                                            <image src="assets/img/image/searchbook.png" width="75px" height="75px"/><br><br>
                                            <form method="post" action="ProjectSearch.php"><style>#icon{ background-image:url(assets/img/image/s.png);} </style>
                                                <div class="drop">
                                                    <select name="one" class="drop-select" required>
                                                        <option value="">Based On</option>
                                                        <option value="0">Project ID</option>
                                                        <option value="1">Title</option>
                                                        <option value="2">Project Area</option>
                                                    </select>
                                                </div>  <br><br>
                                                <input id="icon" style="text-indent:17px;" type="text" placeholder="Search..."name ="project" required/><br><br>
                                                <button class="btn btn-primary fa-1x" name="search"><i class="fa fa-search"></i>&nbsp;Search</button>      
                                            </form><br><br>
                                        </center></div></div></div>
                            <div class="col-lg-12 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <?php
                                    if (isset($_POST['search'])) {
                                        if (empty($_POST['project'])) {
                                            echo'<center><h3 style="font-style:bold;">Enter Anything To Search...</h3></center>';
                                        } else {
                                            echo '<div class="showback" style="color:#000;">';
                                            echo'<table>';
                                            echo'<thead>';
                                            echo'<tr>';
                                            echo' <th>Project Id</th>';
                                            echo'<th>Title</th>';
                                            echo'<th>Project Area</th>';
                                            echo' <th>Status</th>';
                                            echo'</tr></thead><tbody>';
                                            $word = $_POST['project'];
                                            $word = strtolower($word);
                                            $count = str_word_count($word);
                                            require 'dbconnect.php';




                                            if ($_POST['one'] == '0') {
                                                $query = "SELECT * FROM project WHERE id='$word'";
                                                $sql = $conn->query($query);
                                                if ($sql->num_rows > 0) {
                                                    while ($row = $sql->fetch_assoc()) {

                                                        if ($row['status'] == "available") {
                                                            ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                            echo $row['id'];
                                                            $BKID = $row['id'];
                                                            ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                } else {
                                                                    echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td>  <td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                }
                                                            }
                                                        } else {
                                                            echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                        }
                                                    }





                                                    if ($_POST['one'] == '1') {
                                                        $query = "SELECT * FROM project WHERE title LIKE '%" . $word . "%'";
                                                        $sql = $conn->query($query);
                                                        if ($sql->num_rows > 0) {
                                                            while ($row = $sql->fetch_assoc()) {

                                                                if ($row['status'] == "available") {
                                                                    ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                    echo $row['id'];
                                                                                    $BKID = $row['id'];
                                                                                    ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                } else {
                                                                    echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td>  <td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                }
                                                            }
                                                        } elseif ($count > 1) {
                                                            $pieces = explode(" ", $word);
                                                            $query1 = "SELECT * FROM project WHERE title LIKE '%" . $pieces[0] . "%'";
                                                            $query2 = "SELECT * FROM project WHERE title LIKE '%" . $pieces[1] . "%'";
                                                            $sql1 = $conn->query($query1);
                                                            $sql2 = $conn->query($query2);
                                                            if ($sql1->num_rows > 0) {
                                                                while ($row = $sql1->fetch_assoc()) {
                                                                    if ($row['status'] == "available") {
                                                                        ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                        echo $row['id'];
                                                                                        $BKID = $row['id'];
                                                                                        ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                    } else {
                                                                        echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td>  <td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                    }
                                                                }
                                                            } elseif ($sql2->num_rows > 0) {
                                                                while ($row = $sql2->fetch_assoc()) {
                                                                    if ($row['status'] == "available") {
                                                                        ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                        echo $row['id'];
                                                                                        $BKID = $row['id'];
                                                                                        ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                    } else {
                                                                        echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td>  <td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                    }
                                                                }
                                                            } else {
                                                                echo '<tr><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                            }
                                                        } else {
                                                            echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                        }
                                                    }
                                                    if ($_POST['one'] == '2') {
                                                        $query = "SELECT * FROM  project WHERE area LIKE '%" . $word . "%'";
                                                        $sql = $conn->query($query);
                                                        if ($sql->num_rows > 0) {
                                                            while ($row = $sql->fetch_assoc()) {

                                                                if ($row['status'] == "available") {
                                                                    ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                    echo $row['id'];
                                                                                    $BKID = $row['id'];
                                                                                    ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                } else {
                                                                    echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td><td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                }
                                                            }
                                                        } elseif ($count > 1) {
                                                            $pieces = explode(" ", $word);
                                                            $query1 = "SELECT * FROM  project WHERE  area LIKE '%" . $pieces[0] . "%'";
                                                            $query2 = "SELECT * FROM  project WHERE area LIKE '%" . $pieces[1] . "%'";
                                                            $sql1 = $conn->query($query1);
                                                            $sql2 = $conn->query($query2);
                                                            if ($sql1->num_rows > 0) {
                                                                while ($row = $sql1->fetch_assoc()) {
                                                                    if ($row['status'] == "available") {
                                                                        ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                        echo $row['id'];
                                                                                        $BKID = $row['id'];
                                                                                        ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                    } else {
                                                                        echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td><td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                    }
                                                                }
                                                            } elseif ($sql2->num_rows > 0) {
                                                                while ($row = $sql2->fetch_assoc()) {
                                                                    if ($row['status'] == "available") {
                                                                        ?>  <tr><td style="color:#f67854" class="user-name"><?php
                                                                                        echo $row['id'];
                                                                                        $BKID = $row['id'];
                                                                                        ?></td><td class="user-name"><?php echo $row['title']; ?></td><td class="user-phone"><?php echo $row['area']; ?></td>  <td class="user-name"><form method="post" action="ProjectReserve.php"><input type="text" class="display hidden" value="<?php echo $BKID; ?>" name="BKID"><button class="but"><i class="fa fa-book"></i>&nbsp;<span>Book&nbsp</span></button></form></td></tr> <?php
                                                                    } else {
                                                                        echo '<tr><td style="color:#f67854" class="user-name">' . $row['id'] . '</td><td class="user-name">' . $row['title'] . '</td><td class="user-phone">' . $row['area'] . '</td><td style="color:red;font-size:16px;font-family:calibri;" class="user-name">Not Available</td></tr>';
                                                                    }
                                                                }
                                                            } else {
                                                                echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                            }
                                                        } else {
                                                            echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                        }
                                                    }


                                                    if ($_POST['one'] == "") {
                                                        echo'<center><h3 style="font-style:bold;">Please Select,Search project  Based On</h3></center>';
                                                    }
                                                }
                                            }
                                            echo'  </tbody>';
                                            echo' </table>';
                                            echo'</body>';
                                            echo' </div>';
                                            ?>
                                </div>	
                            </div><!-- /col-lg-9 END SECTION MIDDLE -->
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end--><br><br><br><br>
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>