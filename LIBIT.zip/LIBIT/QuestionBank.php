<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <?php if (!empty($_SESSION['error'])) { ?>
                            <h4 class="alert alert-success">
                                <?php echo $_SESSION['error']; ?>
                                <span class="closebtn">&times;</span>  
                                <script>
                                    var close = document.getElementsByClassName("closebtn");
                                    var i;

                                    for (i = 0; i < close.length; i++) {
                                        close[i].onclick = function () {
                                            var div = this.parentElement;
                                            div.style.opacity = "0";
                                            setTimeout(function () {
                                                div.style.display = "none";
                                            }, 600);
                                        }
                                    }
                                </script></h4><?php } ?><?php
                        if (!empty($_SESSION['error'])) {
                            unset($_SESSION['error']);
                        }
                        ?>
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-book"></i> &nbsp;Question&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="showback" style="color:#000;">
                                        <center> <link rel="stylesheet" type="text/css" href="assets/css/scss.css"><link rel="stylesheet" type="text/css" href="assets/css/component.css" />
                                            <center> 
                                                <h3>Search Question</h3>
                                                <image src="assets/img/image/searchbook.png" width="75px" height="75px"/><br><br>
                                                <form method="post" action="QuestionBank.php"><style>#icon{ background-image:url(assets/img/image/s.png);} </style>
                                                    <div class="drop">
                                                        <select name="one" class="drop-select" required>
                                                            <option value="">Based On</option>
                                                            <option value="1">Subject Code</option>
                                                            <option value="2">Subject Name</option>
                                                        </select>
                                                    </div>  <br><br>
                                                    <input id="icon" style="text-indent:17px;" type="text" placeholder="Search..."name ="question" required /><br><br>
                                                    <button class="btn btn-primary fa-1x" name="search"><i class="fa fa-search"></i>&nbsp;Search</button>      
                                                </form><br><br><br>
                                            </center>
                                        </center></div></div></div>
                            <div class="col-lg-12 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <?php
                                    if (isset($_POST['search'])) {
                                        if (empty($_POST['question'])) {
                                            echo'<center><h3 style="font-style:bold;">Enter Anything To Search...</h3></center>';
                                        } else {
                                            echo '<div class="showback" style="color:#000;">';
                                            echo'<table>';
                                            echo'<thead>';
                                            echo'<tr>';
                                            echo'<th>Subject Code</th>';
                                            echo'<th>Subject Name</th>';
                                            echo'<th>Regulation</th>';
                                            echo' <th>Download</th>';
                                            echo'</tr></thead><tbody>';
                                            $word = $_POST['question'];
                                            $word = strtolower($word);
                                            $count = str_word_count($word);
                                            require 'dbconnect.php';





                                            if ($_POST['one'] == '1') {
                                                $query = "SELECT * FROM question WHERE SubjectCode='$word'";
                                                $sql = $conn->query($query);
                                                if ($sql->num_rows > 0) {
                                                    while ($row = $sql->fetch_assoc()) {

                                                            ?>             <tr><?php 
                                                            require 'config.php';
                                                            $FilePath.=$row['FileName'];
                                                    ?><td class="user-name"><?php echo $row['SubjectCode']; ?></td><td class="user-phone"><?php echo $row['SubjectName']; ?></td><td class="user-phone"><?php echo $row['Regulation']; ?></td><td class="user-name"><a href="<?php echo $FilePath; ?>"><button class="but"><i class="fa fa-download"></i>&nbsp;Download&nbsp;</button></a></td></tr> <?php
                                                            }
                                                        } else {
                                                            echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                        }
                                                    }







                                                    if ($_POST['one'] == '2') {
                                                        $query = "SELECT * FROM  question WHERE SubjectName LIKE '%" . $word . "%'";
                                                        $sql = $conn->query($query);
                                                        if ($sql->num_rows > 0) {
                                                            while ($row = $sql->fetch_assoc()) { ?>  
                                                            <tr><?php 
                                                                                    require 'config.php';
                                                                                    $FilePath.=$row['FileName'];
                                                                            ?><td class="user-name"><?php echo $row['SubjectCode']; ?></td><td class="user-phone"><?php echo $row['SubjectName']; ?></td><td class="user-phone"><?php echo $row['Regulation']; ?></td><td class="user-name"><a href="<?php echo $FilePath; ?>"><button class="but"><i class="fa fa-download"></i>&nbsp;Download&nbsp;</button></a></td></tr> <?php
                                                            }
                                                        } elseif ($count > 1) {
                                                            $pieces = explode(" ", $word);
                                                            $query1 = "SELECT * FROM  question WHERE  SubjectName LIKE '%" . $pieces[0] . "%'";
                                                            $query2 = "SELECT * FROM  question WHERE SubjectName LIKE '%" . $pieces[1] . "%'";
                                                            $sql1 = $conn->query($query1);
                                                            $sql2 = $conn->query($query2);
                                                            if ($sql1->num_rows > 0) {
                                                                while ($row = $sql1->fetch_assoc()) {
                                                                        ?>             <tr><?php 
                                                                                        require 'config.php';
                                                                                        $FilePath.=$row['FileName'];
                                                                                ?><td class="user-name"><?php echo $row['SubjectCode']; ?></td><td class="user-phone"><?php echo $row['SubjectName']; ?></td><td class="user-phone"><?php echo $row['Regulation']; ?></td><td class="user-name"><a href="<?php echo $FilePath; ?>"><button class="but"><i class="fa fa-download"></i>&nbsp;Download&nbsp;</button></a></td></tr> <?php
                                                                      }
                                                            } elseif ($sql2->num_rows > 0) {
                                                                while ($row = $sql2->fetch_assoc()) {
                                                                        ?>             <tr><?php 
                                                                                        require 'config.php';
                                                                                        $FilePath.=$row['FileName'];
                                                                                ?><td class="user-name"><?php echo $row['SubjectCode']; ?></td><td class="user-phone"><?php echo $row['SubjectName']; ?></td><td class="user-phone"><?php echo $row['Regulation']; ?></td><td class="user-name"><a href="<?php echo $FilePath; ?>"><button class="but"><i class="fa fa-download"></i>&nbsp;Download&nbsp;</button></a></td></tr> <?php
                                                                    }
                                                            } else {
                                                                echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                            }
                                                        } else {
                                                            echo '<tr ><td colspan="4" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                                        }
                                                    }


                                                    if ($_POST['one'] == "") {
                                                        echo'<center><h3 style="font-style:bold;">Please Select, Search Question Based On</h3></center>';
                                                    }
                                                }
                                            }
                                            echo'</tbody>';
                                            echo' </table>';
                                            echo' </div>';
                                            ?>
                                </div>	
                            </div><!-- /col-lg-9 END SECTION MIDDLE -->
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end--><br><br><br><br>
                <?php include 'Links/Footer.php'; ?>
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>