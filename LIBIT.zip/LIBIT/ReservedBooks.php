<ul class="dropdown-menu extended inbox">
    <div class="notify-arrow notify-arrow-green"></div>
    <li>
        <p class="green">

            Your Reserved Books

        </p>
    </li>


    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    } require 'dbconnect.php';
    if (isset($_SESSION['GateWay'])) {
        $uid = $_SESSION['username'];
        $query = "SELECT id FROM booking where  rollno ='$uid'";
        $sql = $conn->query($query);
        if ($sql->num_rows > 0) {
            while ($row = $sql->fetch_assoc()) {


                $bookid = $row['id'];
                $query1 = "SELECT * FROM book WHERE id='$bookid' AND status='available'";
                $sql1 = $conn->query($query1);
                $query2 = "SELECT * FROM project WHERE id='$bookid' AND status='available'";
                $sql2 = $conn->query($query2);
                $query3 = "SELECT * FROM manual WHERE id='$bookid' AND status='available'";
                $sql3 = $conn->query($query3);
                $query4 = "SELECT * FROM journal WHERE id='$bookid' AND status='available'";
                $sql4 = $conn->query($query4);
                if ($sql1->num_rows > 0) {
                    while ($row1 = $sql1->fetch_assoc()) {

                        $bookName = $row1['title'];
                    }
                } elseif ($sql2->num_rows > 0) {
                    $flag = 1;
                    while ($row2 = $sql2->fetch_assoc()) {

                        $bookName = $row2['title'];
                    }
                } elseif ($sql3->num_rows > 0) {
                    while ($row3 = $sql3->fetch_assoc()) {
                        $bookName = $row3['title'];
                    }
                } elseif ($sql4->num_rows > 0) {
                    while ($row4 = $sql4->fetch_assoc()) {
                        $bookName = $row4['title'];
                    }
                }
                ?>
                <li>
                    <a href="#">
                        <span class="photo"><img alt="avatar" src="assets/img/logo.png"></span>
                        <span class="subject">
                            <span class="from">Reserved</span>
                        </span>
                        <span class="message">
                            <?php echo $bookName; ?>
                        </span>
                    </a>
                </li>
                <?php
            }
        } else {
            ?>
            <li>
                <a href="#">
                    <span class="photo"><img alt="avatar" src="assets/img/logo.png"></span>
                    <span class="subject">
                        <span class="from">Reserved</span>
                    </span>
                    <span class="message">
                        No Data Available 
                    </span>
                </a>
            </li>
            <?php
        }
    } else {
        ?>
        <li>
            <a href="#">
                <span class="photo"><img alt="avatar" src="assets/img/logo.png"></span>
                <span class="subject">
                    <span class="from">                  No Data Available Login & Try
                    </span>
                </span>  
            </a>
        </li>
    <?php } ?>
</ul>