<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include("dbconnect.php");
$name = $newpd = $oldpd = "";
$name = $_POST['rname'];
$opassword = $_POST['opassword'];
$sql = "SELECT * FROM login where name='$name'";
$result = $conn->query($sql);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (empty($_POST['rname'])) {
        $_SESSION['smsg'] = "Name Is Required";
        header("location: Reset.php");
    } elseif (empty($_POST['opassword'])) {
        $_SESSION['smsg'] = "Old Password Is Required";
        header("location: Reset.php");
    } elseif (empty($_POST['npassword'])) {
        $_SESSION['smsg'] = "New Password Is Required";
        header("location: Reset.php");
    } elseif (empty($_POST['cpassword'])) {
        $_SESSION['smsg'] = "Confirm Password Is Required";
        header("location: Reset.php");
    } elseif (($_POST["npassword"]) != ($_POST['cpassword'])) {
        $_SESSION['smsg'] = "Confirm & New password are not same";
        header("location: Reset.php");
    } elseif ($result->num_rows <= 0) {
        $_SESSION['smsg'] = " Please Enter Registered Name";
        header("location: Reset.php");
    } elseif ($result->num_rows > 0) {
        $name = $_POST["rname"];
        $cpassword = $_POST["cpassword"];
        $password = md5($cpassword);
        $sql = "UPDATE login SET password='$password' WHERE name='$name'";
        if (mysqli_query($conn, $sql)) {
            header("location: Index.php");
        } else {
            $_SESSION['smsg'] = "Enter Valid username or password";
            header("location: Reset.php");
        }
    }
}

function is_connected() {
    $connected = @fsockopen("www.google.com", 80);
    if ($connected) {
        $is_conn = true;
    } else {
        $is_conn = false;
    }
    return $is_conn;
}

$is_conn = is_connected();
if ($is_conn) {
    $sql = "SELECT * FROM login where name='$name'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $email = $row["email"];
        }
    }
    $subject = "your password Reseted";
    $url = "http://localhost/Php1/Index.php";
    $message = "
<html>
<head>
<title>Department Library Login</title>
</head>
<body>
<table  style='border-color: #666;' cellpadding='10'>
<tr style='background: #eee;'><td style='color:green'><strong>!!!!...From Department Library...!!!!<br><br> Your Password Have Been Changed</strong></td></tr>
			</table>        
                        
                        <table  style='border-color: #666;' cellpadding='10'>
<tr style='background: #eee;'><td><strong>Your UserName</strong> </td><td><p style='color:red; font-family:calibri; text-align: center;font-size: 15px'>" . $name . "</p></td></tr>
			</table>                        
                        <table  style='border-color: #666;' cellpadding='10'>
<tr style='background: #eee;'><td><strong>Your New Password</strong> </td><td><p style='color:red; font-family:calibri; text-align: center;font-size: 15px'>" . $cfpassword . "</p></td></tr>
			</table>                        
<table  style='border-color: #666;' cellpadding='10'>
<tr style='background: #eee;'><td><strong>Click Here To Check Your Username & Password Is Valid</strong> </td><td><p style='color:blue; font-family:calibri; text-align: center;font-size: 15px'>" . $url . "</p></td></tr>
			</table>                        
</body>
</html>
";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: ' . $email . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
    $headers .= 'Cc:' . $email . "\r\n";
    $message = wordwrap($message, 70);
    $result = mail($email, $subject, $message, $headers);
    if ($result) {
        header("location: Index.php");
    }
} else {
    $_SESSION['fmsg'] = "PassWord Changed Unable To Send Mail";
    header("location: Forgot.php");
}
mysqli_close($conn);
?>           



