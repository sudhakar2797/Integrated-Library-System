<?php

if (isset($_POST['send'])) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    require 'dbconnect.php';
    $date = date('Y-m-d');
    $query = "SELECT * FROM transaction WHERE status='granted' AND returndate <='$date' ";
    $sql = $conn->query($query);
    if ($sql->num_rows > 0) {
        while ($row = $sql->fetch_assoc()) {
            $rollno = $row['id'];
            $returndate = $row['returndate'];
            $query1 = "SELECT * FROM register WHERE rollno='$rollno' ";
            $sql1 = $conn->query($query1);
            if ($sql1->num_rows > 0) {
                while ($row1 = $sql1->fetch_assoc()) {
                    $subject = "Return Date exceed";
                    $message = " 
                                <center>
                                    <div style=' width:70% ;border-radius: 1.5px; text-align: center; border: 4px solid #000 ;word-wrap: word-break; '>
                                        <p style='color:#357ae8; font-size:25px;font-family:calibre;'>
                                            !!!...Department Library...!!!
                                        </p>
                                        <p style='color:#000'>
                                            Please Return / Renew Your Book
                                        </p>
                                        <p style='color:#Red'>  
                                            Actual Date Of Return - " . $returndate . " 
                                        </p>
                                    </div>
                                </center> ";
                    $remail = row1['emailid'];
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                    $result = mail($remail, $subject, $message, $headers);
                    if ($result) {
                        $_SESSION['merror'] = "Mail Successfully Sended";
                        header("location: MailAlert.php");
                    } else {
                        echo $_SESSION['merror'] = "Please Try Again";
                        header("location: MailAlert.php");
                    }
                }
            }
        }
    }
}
?>


