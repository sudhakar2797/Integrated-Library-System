<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    ?><!DOCTYPE html>
    <html lang="en">
        <?php include 'Links/CSS.php'; ?>
        <body>
            <section id="container" >
                <?php include 'Links/Navigation.php'; ?>
                <?php include 'Links/Menu.php'; ?>
                <!-- **********************************************************************************************************************************************************
                MAIN CONTENT
                *********************************************************************************************************************************************************** -->
                <!--main content start-->
                <section id="main-content">
                    <section class="wrapper">
                        <div class="row">
                            <h3 style="color:#000">&nbsp;<i class="fa fa-gavel"></i> &nbsp;Student Rules&nbsp;&nbsp;<a href="Home.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                            <div class="col-lg-9 main-chart">		
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="showback">
                                        <div style="color: #000"><center> <i class="fa fa-users fa-4x"></i></center>
                                            <h6>   
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Strict silence should be maintained in the reading room.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Identity card is a must while visiting and using the library.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Students should not carry any book (or) printed matters into the Library.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Open-access system is followed. <br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Students can have the books for two weeks (i.e. 14 days) from the date of issue.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Books will be issued and returned on all working days.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Students should not write or draw anything on the books, periodicals and newspapers.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Students will be responsible for any damage done to the books or to other library properties. <br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Reservation of borrowed books by others may be made in a Register available in the library.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Readers shall not write upon, damage, or make any mark upon any book, journal or magazine, or other material belonging to the library.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Any reader observing a defect, or damage to any book or manuscript shall point out the same to the Library Staff immediately.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Borrowers must satisfy themselves about the physical condition of the book before borrowing. <br><br>
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Otherwise they will be responsible for any damage at the time of returning.<br><br>  
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Books borrowed on a particular day will not be accepted for return on the  same day.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;Books taken for reference from the stack area need to be kept on the table and not on the shelves.<br><br>      
                                                <i class="fa fa-leaf fa-1x"></i>&nbsp;The Librarian is empowered to send out any student who makes a noise or misbehaves in the Library.<br><br>      
                                            </h6>
                                        </div> 
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            </div>
                            <?php include 'Links/Topers.php'; ?>
                        </div><! --/row -->
                    </section>
                </section>
                <!--main content end-->
            </section>
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/jquery-1.8.3.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="assets/js/common-scripts.js"></script>
            <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>