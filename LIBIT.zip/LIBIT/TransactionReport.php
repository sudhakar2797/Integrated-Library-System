<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-wrench"></i> &nbsp;Transaction &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback" style="color: #000;">
                                            <link rel="stylesheet" href="assets/css/report.css">     
                                            <style>
                                                .ui-datepicker-calendar {
                                                    display: none;
                                                }
                                                input[type=text] {
                                                    width: 190px;
                                                    box-sizing: border-box;
                                                    border: 2px solid #ccc;
                                                    border-radius: 4px;
                                                    font-size: 14px;
                                                    background-color: white;
                                                    background-repeat: no-repeat;
                                                    padding: 8px 20px 8px 45px;
                                                    -webkit-transition: width 0.4s ease-in-out;
                                                    transition: width 0.4s ease-in-out;
                                                }
                                                input[type=date]:focus {
                                                    width: 45%;
                                                }
                                            </style>
                                            <center>  
                                                <div  align="center"> <br>
                                                    <h3 style="color:#000;">  Monthly Transaction Report</h3>
                                                    <form method="get" action="TransactionReportPDF.php">
                                                        <center><image src="assets/img/image/report3.png" width="120px" height="120px"/></center><br>
                                                        <input  style="background-image:url(assets/img/image/r.png);" type="text" class="date-picker" placeholder="    Date..." name="month" required>
                                                        <br><br>
                                                        <button class="btn btn-primary fa-1x" name="showme"><i class="fa fa-laptop"></i>Show Me</button>      
                                                    </form><br>
                                                </div>
                                            </center>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
                <link rel="stylesheet" href="jq/jquery-ui.css">
                <script src="jq/jquery.js"></script>
                <script src="jq/jquery-ui.js"></script>
                <script type="text/javascript">
                    $(function () {
                        $('.date-picker').datepicker({
                            changeMonth: true,
                            changeYear: true,
                            showButtonPanel: true,
                            dateFormat: 'MM yy',
                            onClose: function (dateText, inst) {
                                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
                            }
                        });
                    });
                </script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
