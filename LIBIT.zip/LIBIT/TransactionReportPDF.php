<?php

$month = $depart = "";
if (isset($_GET['showme'])) {
    $month = $_GET['month'];
    $month = strtotime($month);
    $mon = date('m', $month);
    $year = date('Y', $month);
}
require('fpdf.php');

class PDF extends FPDF {

// Page header
    function Header() {
        $month = $_GET['month'];
        $month = strtotime($month);
        $mont = date('M', $month);
        $year = date('Y', $month);
// Logo
        $this->Image('assets/img/image/kcet.png', 100, 6, 100, 15);
        // Arial bold 15
        $this->Ln(20);
        $this->SetY(25);
        $this->SetX(10);
        // Arial italic 8
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 0, "Month : " . $mont, 0, 0, 'l');
        $this->SetY(25);
        $this->SetX(250);
        // Arial italic 8
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 0, "Year : " . $year, 0, 0, 'l');
    }

// Page footer
    function Footer() {
        // Position at 1.5 cm from bottom
        $this->SetY(-10);
        $this->SetX(0);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        date_default_timezone_set('Asia/Kolkata');
        $date = date('d-m-Y h:i:sa');
        // Position at 1.5 cm from bottom
        $this->SetY(-11);
        $this->SetX(140);
        // Arial italic 8
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(0, 0, $date, 0, 0, 'C');
    }

}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AddPage('L', 'A4');
//Fields Name position
$Y_Fields_Name_position = 30;
//Table position, under Fields Name
$Y_Table_Position = 36;
//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(232, 232, 232);
//Bold Font for Field Name
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(1);
$pdf->Cell(10, 6, 'S.No', 1, 0, 'L', 1);
$pdf->SetX(11);
$pdf->Cell(19, 6, 'RollNo', 1, 0, 'L', 1);
$pdf->SetX(30);
$pdf->Cell(80, 6, 'Name', 1, 0, 'L', 1);
$pdf->SetX(110);
$pdf->Cell(20, 6, 'BookID', 1, 0, 'L', 1);
$pdf->SetX(130);
$pdf->Cell(90, 6, 'Book Name', 1, 0, 'L', 1);
$pdf->SetX(220);
$pdf->Cell(25, 6, 'Issue Date', 1, 0, 'L', 1);
$pdf->SetX(245);
$pdf->Cell(25, 6, 'Return Date', 1, 0, 'L', 1);
$pdf->SetX(270);
$pdf->Cell(26, 6, 'Status', 1, 0, 'L', 1);
$pdf->Ln();
$sno = 1;
//Connect to your database
include("dbconnect.php");
//Select the Products you want to show in your PDF file
$query = "SELECT * FROM transaction WHERE YEAR(issuedate) = '$year' AND MONTH(issuedate)='$mon' ";
$sql = $conn->query($query);
$number_of_records = $sql->num_rows;
while ($row = $sql->fetch_assoc()) {
    $id = $row['id'];
    $bookid = $row['bookid'];
    $bookname = $row['bookname'];
    $issuedate = $row['issuedate'];
    $returndate = $row['returndate'];
    $status = $row['status'];
    $sql1 = "SELECT * FROM register WHERE rollno='$id'";
    $result = $conn->query($sql1);
    $row1 = $result->fetch_assoc();
    $name = $row1['name'];
//Now show the 3 columns
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(1);
    $pdf->MultiCell(10, 6, $sno, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(11);
    $pdf->MultiCell(19, 6, $id, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(30);
    $pdf->MultiCell(80, 6, $name, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(110);
    $pdf->MultiCell(20, 6, $bookid, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(130);
    $pdf->MultiCell(90, 6, $bookname, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(220);
    $pdf->MultiCell(25, 6, $issuedate, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(245);
    $pdf->MultiCell(25, 6, $returndate, 1);
    $pdf->SetY($Y_Table_Position);
    $pdf->SetX(270);
    $pdf->MultiCell(26, 6, $status, 1);
    $pdf->SetY($Y_Table_Position);
    $Y_Table_Position += 6;
    $sno++;
}
//For each row, add the field to the corresponding column
$pdf->Output();
?>
