<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><?php
        $error = "";
        if (isset($_POST['delete'])) {
            if (!empty($_POST['userid'])) {
                $userid = $_POST['userid'];
                require 'dbconnect.php';
                $query = "SELECT *  FROM register WHERE rollno='$userid'";
                $sql = $conn->query($query);
                if ($sql->num_rows > 0) {
                    $query = "DELETE  FROM register WHERE rollno='$userid'";
                    if ($conn->query($query)) {
                        $error = " Records Successfully Deleted";
                    } else {
                        $error = " Please Try Again";
                    }
                } else {
                    $error = " Enter Valid User ID...";
                }
            }
        }
        ?>  
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-user"></i> &nbsp;User &nbsp;&nbsp;<a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback">
                                            <?php if (!empty($error)) { ?>
                                                <h4 class="alert alert-success">
                                                    <?php echo $error; ?>
                                                    <span class="closebtn">&times;</span>  
                                                    <script>
                                                        var close = document.getElementsByClassName("closebtn");
                                                        var i;

                                                        for (i = 0; i < close.length; i++) {
                                                            close[i].onclick = function () {
                                                                var div = this.parentElement;
                                                                div.style.opacity = "0";
                                                                setTimeout(function () {
                                                                    div.style.display = "none";
                                                                }, 600);
                                                            }
                                                        }
                                                    </script></h4><?php } ?>
                                            <center style="color:#000;"><link href="assets/css/delete.css"rel="stylesheet">
                                                <h3 style="font-family:calibri;color: #357ae8;">Delete User </h3>
                                                <form method="post" action="UserDelete.php">
                                                    <image src="assets/img/image/deleteuser.png" width="75px" height="75px"/><br><br>
                                                    <input  type="text"  placeholder="Enter The User Roll Number" name="userid" required><br><br><br>
                                                    <button class="btn btn-success fa-1x" name="delete"><i class=" fa fa-trash-o"></i>&nbsp;Delete It</button>      
                                                </form><br><br> 
                                            </center>
                                        </div>      
                                    </div>	
                                </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
