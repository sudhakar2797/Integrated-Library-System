<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}if (isset($_SESSION['GateWay'])) {
    if ($_SESSION['GateWay'] = 'ADMIN') {
        ?><?php
        $nameerror = $error = $roleerror = $dateofadderror = $emailiderror = "";
        $acc = 0;
        if (isset($_POST['update'])) {
            $acc = 1;
            $error = " Nothing Updated";
            require 'dbconnect.php';
            if (!empty($_POST['rollno'])) {
                $rollno = $_POST['rollno'];
                $query = "SELECT * FROM Register WHERE rollno='$rollno'";
                $sql = $conn->query($query);
                if ($sql->num_rows > 0) {

                    if (!empty($_POST['newname'])) {
                        $name = $_POST['newname'];
                        $sql = "UPDATE register SET name='$name' WHERE rollno='$rollno'";
                        if ($conn->query($sql)) {
                            $nameerror = " Name Successfully Updated";
                        } else {
                            $nameerror = " Name Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['nrollno'])) {
                        $name = $_POST['nrollno'];
                        $sql = "UPDATE register SET rollno='$name' WHERE rollno='$rollno'";
                        $sql1 = "UPDATE login SET name='$name' WHERE name='$rollno'";
                        if (($conn->query($sql)) && ($conn->query($sql1))) {
                            $nameerror .= " rollNo Successfully Updated";
                        } else {
                            $nameerror .= " Name Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newrole'])) {
                        $role = $_POST['newrole'];
                        $sql = "UPDATE register SET role='$role' WHERE rollno='$rollno'";
                        if ($conn->query($sql)) {
                            $roleerror = "Role Successfully Updated";
                        } else {
                            $roleerror = " Role Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newemailid'])) {
                        $emailid = $_POST['newemailid'];
                        $sql = "UPDATE register SET emailid='$emailid' WHERE rollno='$rollno'";
                        if ($conn->query($sql)) {
                            $emailiderror = "EmailID Successfully Updated";
                        } else {
                            $emailiderror = "EmailID Not Updated Please Try Again";
                        }
                    }
                    if (!empty($_POST['newdateofadd'])) {
                        $dateofadd = $_POST['newdateofadd'];
                        $old = strtotime($dateofadd);
                        $dateofadd = date('Y-m-d ', $old);
                        $sql = "UPDATE register SET dateofadd='$dateofadd' WHERE rollno='$rollno'";
                        if ($conn->query($sql)) {
                            $dateofadderror = "Date Of Add Successfully Updated";
                        } else {
                            $dateofadderror = " Date Of Add Not Updated Please Try Again";
                        }
                    }
                } else {
                    $error = "Please Enter Valid Roll Number";
                }
            } else {
                $error = "Please Enter Roll Number";
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
            <?php include 'Links/CSS.php'; ?>
            <body>
                <section id="container" >
                    <?php include 'Links/Navigation.php'; ?>
                    <?php include 'Links/Menu.php'; ?>
                    <!-- **********************************************************************************************************************************************************
                    MAIN CONTENT
                    *********************************************************************************************************************************************************** -->
                    <!--main content start-->
                    <section id="main-content">
                        <section class="wrapper">
                            <div class="row">
                                <h3 style="color:#000">&nbsp;<i class="fa fa-user"></i> &nbsp;User&nbsp;&nbsp; <a href="Panel.php"><button class="btn btn-primary" style="width: 75px"><i class="fa fa-exchange"></i>&nbsp;Back</button></i></a></h3>
                                <div class="col-lg-9 main-chart">		
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="showback" style="color:#000;">
                                            <style>             
                                                input[type=text]:focus {
                                                    width: 55%;
                                                }
                                                input[type=text]:hover {
                                                    width: 55%;
                                                }
                                            </style>
                                            <center> 
                                                <form method="post" action="UserUpdate.php">
                                                    <link rel="stylesheet" href="assets/css/update.css">
                                                    <?php if ($acc == 1) { ?>  <link href="assets/css/alert.css" rel="stylesheet">
                                                        <div class="alert alert-danger">
                                                            <span class="closebtn">&times;</span>  
                                                            <?php
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $error . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $nameerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $roleerror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $emailiderror . '</h3>';
                                                            echo '<h3 style="font-size:17px;color:white;font-family:calibri;">' . $dateofadderror . '</h3>';
                                                            ?>
                                                        </div>
                                                        <script>
                                                            var close = document.getElementsByClassName("closebtn");
                                                            var i;

                                                            for (i = 0; i < close.length; i++) {
                                                                close[i].onclick = function () {
                                                                    var div = this.parentElement;
                                                                    div.style.opacity = "0";
                                                                    setTimeout(function () {
                                                                        div.style.display = "none";
                                                                    }, 600);
                                                                }
                                                            }
                                                        </script><?php } ?> 
                                                    <div align="center">
                                                        <ul class="tab">
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Id')" id="defaultOpen">RollNumber</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Name')">Name</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Role')">Role</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'EmailID')">EmailID</a></li>
                                                            <li><a href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'DateOfAdd')">DateOfAdd</a></li>
                                                        </ul>
                                                        <div id="Id" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <center> <image src="assets/img/image/updateuser.png" width="75px" height="75px"/></center>
                                                            <h3 style="font-size:25px;color:maroon;font-family:calibri;">User Update</h3><br>
                                                            <input type="text" id="icon" name="rollno" placeholder="Enter The Roll Number, You Want To Update"/><br><br>
                                                            <input type="text" id="icon" name="nrollno" placeholder="New Roll Number"/><br>
                                                            <br><button name="update" class="btn btn-primary fa-1x"><i class="fa fa-edit"></i>&nbsp;update</button>
                                                            <h4 style="font-family: calibri;font-size: 20px;color:indigo; ">** If You Don't Known About The Roll Number Please Use " Display Option " To Find The Roll Number **</h4>
                                                        </div>
                                                        <div id="Name" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change User Name</h3><br>
                                                            <input type="text" id="icon" name="newname" placeholder="Enter The  New User Name"/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br>
                                                        </div>
                                                        <div id="Role" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Role Of The User</h3><br>
                                                            <input type="text" id="icon" name="newrole" placeholder="Enter The New Role"/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br></div>
                                                        <div id="EmailID" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change EmailID Of The User</h3><br>
                                                            <input type="text" id="icon" name="newemailid" placeholder="      Enter The New EmailID Of User   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br></div>
                                                        <div id="DateOfAdd" class="tabcontent">
                                                            <span onclick="this.parentElement.style.display = 'none'" class="topright">x</span>
                                                            <br><br><h3 style="font-size:25px;color:maroon;font-family:calibri;">Change Date Of Add</h3><br>
                                                            <input type="text" id="icon" name="newdateofadd"  id="datepicker1" placeholder="        Enter The New Date Of Add   "/><br><br>
                                                            <h4 style="font-size:20px;color:darkorchid;font-family:calibri;"> ** Optional **</h4><br><br></div>
                                                    </div>
                                                </form>
                                            </center>
                                            <script>
                                                function openCity(evt, cityName) {
                                                    var i, tabcontent, tablinks;
                                                    tabcontent = document.getElementsByClassName("tabcontent");
                                                    for (i = 0; i < tabcontent.length; i++) {
                                                        tabcontent[i].style.display = "none";
                                                    }
                                                    tablinks = document.getElementsByClassName("tablinks");
                                                    for (i = 0; i < tablinks.length; i++) {
                                                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                                                    }
                                                    document.getElementById(cityName).style.display = "block";
                                                    evt.currentTarget.className += " active";
                                                }
                                                // Get the element with id="defaultOpen" and click on it
                                                document.getElementById("defaultOpen").click();
                                            </script>
                                        </div>	
                                    </div><!-- /col-lg-9 END SECTION MIDDLE -->
                                </div>
                                <?php include 'Links/Topers.php'; ?>
                            </div><! --/row -->
                        </section>
                    </section>
                    <!--main content end-->
                    <?php include 'Links/Footer.php'; ?>
                </section>
                <!-- js placed at the end of the document so the pages load faster -->
                <script src="assets/js/jquery.js"></script>
                <script src="assets/js/jquery-1.8.3.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
                <script src="assets/js/jquery.scrollTo.min.js"></script>
                <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
                <script src="assets/js/jquery.sparkline.js"></script>
                <link rel="stylesheet" href="jq/jquery-ui.css">
                <script src="jq/jquery.js"></script>
                <!--common script for all pages-->
                <script src="assets/js/common-scripts.js"></script>
                <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
                <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
                <script src="jq/jquery-ui.js"></script>
                <script>
                                                $(function () {
                                                    $("#datepicker").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                                                $(function () {
                                                    $("#datepicker1").datepicker();
                                                    $("#format").on("change", function () {
                                                        $("#datepicker1").datepicker("option", "dateFormat", $(this).val());
                                                    });
                                                });
                </script>
            </body>
        </html>
        <?php
    } else {
        header("location:Logout.php");
    }
} else {
    header("location:Logout.php");
}
?>
