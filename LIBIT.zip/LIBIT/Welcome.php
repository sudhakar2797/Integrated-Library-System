<!DOCTYPE html>
<html lang="en">
    <?php include 'Links/CSS.php'; ?>
    <body>
        <section id="container" >
            <?php include 'Links/Navigation.php'; ?>
            <?php include 'Links/WelcomeMenu.php'; ?>
            <!-- **********************************************************************************************************************************************************
            MAIN CONTENT
            *********************************************************************************************************************************************************** -->
            <!--main content start-->
            <section id="main-content">
                <section class="wrapper">
                    <div class="row">
                        <h3 style="color:#000">&nbsp;<i class="fa fa-home"></i> &nbsp;Home</h3>
                        <div class="col-lg-9 main-chart">		
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="showback">
                                    <div class="col-lg-2"><img class="img-responsive" src="assets/img/welcome.jpg" style="width:100px;height: 100px" alt="">
                                    </div><h4 style="color:Black">
                                        <p><i class="fa fa-book red"></i><b>&nbsp;&nbsp;&nbsp;Department Library </b></p>
                                        Libraries store the energy that fuels the imagination. 
                                        They open up windows to the world and inspire us to explore and achieve,and contribute to improving our quality of life	
                                    </h4>	
                                </div>	
                            </div><!-- /col-lg-9 END SECTION MIDDLE -->
                            <a href="OPAC.php"><div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="showback">
                                        <center> <img class="img-responsive" src="assets/img/opac.jpg" style="width:150px;height: 150px" alt="">
                                        <h4 style="color:Black">
                                            <p><i class="fa fa-book red"></i><b>&nbsp;&nbsp;&nbsp;OPAC </b></p>
                                        </h4></center>
                                    </div>
                                    </div></a>
                                <a href="QuestionBank.php"><div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="showback">
                                        <center><img class="img-responsive" src="assets/img/qbank.png" style="width:150px;height: 150px" alt="">
                                        <h4 style="color:Black">
                                            <p><i class="fa fa-book red"></i><b>&nbsp;&nbsp;&nbsp;Question Bank </b></p>
                                        </h4></center>
                                    </div>
                                    </div></a>
                            
                            
                            
                        </div>
                        <?php include 'Links/Topers.php'; ?>
                    </div><! --/row -->
                </section>
            </section>
            <!--main content end-->
            <?php include 'Links/Footer.php'; ?>
            <?php
            date_default_timezone_set('Asia/Calcutta');
            $Hour = date('G');
            $time = "";
            if ($Hour >= 5 && $Hour <= 11) {
                $time = "Good Morning";
            } else if ($Hour >= 12 && $Hour <= 18) {
                $time = "Good Afternoon";
            } else if ($Hour >= 19 || $Hour <= 4) {
                $time = "Good Evening";
            }
            ?>
        </section>
        <!-- js placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/jquery-1.8.3.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="assets/js/jquery.sparkline.js"></script>
        <!--common script for all pages-->
        <script src="assets/js/common-scripts.js"></script>
        <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
        <script type="text/javascript" src="assets/js/gritter-conf.js"></script>
        <!--script for this page-->
        <script src="assets/js/sparkline-chart.js"></script>    
        <script src="assets/js/zabuto_calendar.js"></script>	
        <script type="text/javascript">
            $(document).ready(function () {
                var unique_id = $.gritter.add({
                    // (string | mandatory) the heading of the notification
                    title: 'Welcome to LIB-IT',
                    // (string | mandatory) the text inside the notification
                    text: '<?php echo $time; ?>',
                    // (string | optional) the image to display on the left
                    image: 'assets/img/logo.png',
                    // (bool | optional) if you want it to fade out on its own or just sit there
                    sticky: true,
                    // (int | optional) the time you want it to be alive for before fading out
                    time: '',
                    // (string | optional) the class name you want to apply to that specific message
                    class_name: 'my-sticky-class'
                });

                return false;
            });
        </script>
    </body>
</html>
